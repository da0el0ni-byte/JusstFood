# ¿Qué como hoy?

Aplicación para decidir qué cocinar con los ingredientes que ya tienes en casa. Funciona sin cuenta, sin backend y sin conexión.

Esta versión es una **app web instalable** (PWA) con el mismo flujo, recetas y lógica de anuncios que una app Android. Está pensada para usarse a una mano, en vertical.

## Funciones implementadas

- Selección de ingredientes por grupos, con búsqueda
- Tiempo máximo: 10, 20, 30 o 45 minutos
- Tipo de comida: desayuno, comida, cena, postre o snack
- Preferencias: vegetariano, sin gluten, alto en proteína, económico
- Número de personas, con cantidades ajustadas
- Búsqueda local sobre 50 recetas originales en JSON/TypeScript
- Resultados ordenados por coincidencia de ingredientes
- Filtro “solo recetas que puedo hacer ahora”
- Detalle con ingredientes, faltantes, pasos, tiempo y dificultad
- Favoritos guardados en el dispositivo
- Temporizador en primer plano, con pausa y aviso al terminar
- Anuncios AdMob en modo prueba: banner en resultados, intersticial tras 5 recetas distintas (máximo uno cada 10 minutos) y anuncio recompensado opcional para una receta sorpresa
- Ajustes: borrar favoritos, desactivar anuncios en desarrollo e información de la app

## Cómo usarla aquí

Ábrela en el visor. Elige ingredientes (por ejemplo huevo, arroz y tomate) y pulsa **Buscar recetas**.

En un teléfono, instálala en la pantalla de inicio desde el menú del navegador para usarla como app.

## Android (instalación)

1. Abre la app en Chrome para Android.
2. Menú → **Añadir a la pantalla de inicio** / **Instalar aplicación**.
3. Ábrela desde el icono. No necesita Google Play para esta versión web.

## Anuncios: pasar de prueba a reales

Los IDs de prueba de Google están en `src/lib/ads.ts`.

Antes de publicar, sustituye:

- `ADMOB.appId`
- `ADMOB.bannerId`
- `ADMOB.interstitialId`
- `ADMOB.rewardedId`

Los comentarios del archivo marcan el punto exacto. No publiques con los IDs `ca-app-pub-3940256099942544…`.

Para silenciar todos los anuncios en desarrollo:

- Pon `ADS_DISABLED_BY_DEFAULT = true` en `src/lib/ads.ts`, o
- Activa **Desactivar anuncios (desarrollo)** en Ajustes.

Reglas ya aplicadas:

- El banner reserva su espacio para que la lista no salte
- El intersticial no aparece al abrir la app
- El intersticial no aparece mientras el temporizador está en marcha ni en la pantalla de pasos
- El anuncio recompensado es voluntario y explica qué se obtiene
- No hay textos que pidan pulsar el anuncio

## Recetas

La colección está en `src/data/recipes.ts` y se exporta también a `src/data/recipes.json`. Son 50 recetas originales de cocina casera, no copiadas de sitios de recetas.

## Mejoras futuras

- Envolver la app con Expo o Capacitor para publicar en Google Play con el SDK nativo de AdMob
- Lista de la compra a partir de los ingredientes que faltan
- Plan semanal y restos del día anterior
- Modo oscuro
- Recetas del usuario (solo en el dispositivo)
- Temporizador por paso, con avisos
- Exportar/importar favoritos

## Desarrollo local

```bash
npm install
npm run dev
```
