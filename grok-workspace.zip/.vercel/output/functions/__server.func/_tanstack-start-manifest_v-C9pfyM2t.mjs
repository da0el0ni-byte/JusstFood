//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C9pfyM2t.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/favorites",
			"/results",
			"/settings",
			"/recipe/$id"
		],
		preloads: ["/assets/index-bmdDsWTG.js", "/assets/recipes-B3Dq9gF5.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-bmdDsWTG.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C7nI2S2Y.js", "/assets/format-DMBOZyfq.js"]
	},
	"/favorites": {
		filePath: "/workspace/src/routes/favorites.tsx",
		children: void 0,
		preloads: ["/assets/favorites-DAWrGssG.js", "/assets/RecipeCard-CT2UCtbg.js"]
	},
	"/results": {
		filePath: "/workspace/src/routes/results.tsx",
		children: void 0,
		preloads: [
			"/assets/results-Bxy9iXkA.js",
			"/assets/chevron-left-BMbtoCDG.js",
			"/assets/RecipeCard-CT2UCtbg.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-CMydkxLr.js"]
	},
	"/recipe/$id": {
		filePath: "/workspace/src/routes/recipe.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/recipe._id-ClzU_M4D.js",
			"/assets/chevron-left-BMbtoCDG.js",
			"/assets/RecipeIllustration-Di8WXdND.js",
			"/assets/format-DMBOZyfq.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
