import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as recipes, u as useAppStore } from "./button-CEqpR9ko.mjs";
import { m as Heart } from "../_libs/lucide-react.mjs";
import { a as scoreRecipe } from "./router-B_YNREyx.mjs";
import { t as RecipeCard } from "./RecipeCard-BgsKDekC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-FVaXwJwx.js
var import_jsx_runtime = require_jsx_runtime();
function FavoritesPage() {
	const favorites = useAppStore((s) => s.favorites);
	const hydrated = useAppStore((s) => s.hydrated);
	const ingredientIds = useAppStore((s) => s.ingredientIds);
	const selected = new Set(ingredientIds);
	const items = recipes.filter((recipe) => favorites.includes(recipe.id)).map((recipe) => scoreRecipe(recipe, selected));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pt-8 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-ink",
				children: "Favoritos"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Se guardan en este dispositivo."
			}),
			!hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-muted",
				children: "Cargando…"
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: "mx-auto size-8 text-terra" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-xl",
						children: "Aún no hay favoritos"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ink-soft",
						children: "Abre una receta y pulsa el corazón para guardarla."
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-col gap-3",
				children: items.map((scored) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeCard, { scored }, scored.recipe.id))
			})
		]
	});
}
//#endregion
export { FavoritesPage as component };
