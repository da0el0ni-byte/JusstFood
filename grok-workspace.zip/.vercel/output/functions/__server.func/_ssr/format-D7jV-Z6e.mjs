//#region node_modules/.nitro/vite/services/ssr/assets/format-D7jV-Z6e.js
var CATEGORY_LABEL = {
	desayuno: "Desayuno",
	comida: "Comida",
	cena: "Cena",
	postre: "Postre",
	snack: "Snack"
};
var DIFFICULTY_LABEL = {
	facil: "Fácil",
	media: "Media",
	avanzada: "Avanzada"
};
var TAG_LABEL = {
	vegetariano: "Vegetariano",
	sin_gluten: "Sin gluten",
	alto_proteina: "Alto en proteína",
	economico: "Económico"
};
function formatAmount(amount, unit) {
	const rounded = unit === "ud" || unit === "cda" || unit === "cdta" ? Math.round(amount * 2) / 2 : Math.round(amount);
	const n = Number.isInteger(rounded) ? String(rounded) : String(rounded).replace(".", ",");
	switch (unit) {
		case "ud": return rounded === 1 ? "1 unidad" : `${n} unidades`;
		case "cda": return rounded === 1 ? "1 cucharada" : `${n} cucharadas`;
		case "cdta": return rounded === 1 ? "1 cucharadita" : `${n} cucharaditas`;
		case "g": return `${n} g`;
		case "ml": return `${n} ml`;
		case "pizca": return "1 pizca";
		default: return `${n} ${unit}`;
	}
}
function scaleAmount(amount, recipeServings, people) {
	if (recipeServings <= 0) return amount;
	return amount * people / recipeServings;
}
function formatMinutes(minutes) {
	return `${minutes} min`;
}
//#endregion
export { formatMinutes as a, formatAmount as i, DIFFICULTY_LABEL as n, scaleAmount as o, TAG_LABEL as r, CATEGORY_LABEL as t };
