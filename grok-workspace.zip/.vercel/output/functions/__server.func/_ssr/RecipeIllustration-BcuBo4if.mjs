import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as cn } from "./button-CEqpR9ko.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RecipeIllustration-BcuBo4if.js
var import_jsx_runtime = require_jsx_runtime();
function Frame({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 120 120",
		className: cn("h-full w-full", className),
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "120",
			height: "120",
			rx: "28",
			fill: "#E7EDD4"
		}), children]
	});
}
function RecipeIllustration({ kind, className }) {
	switch (kind) {
		case "eggs": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "48",
					cy: "62",
					rx: "22",
					ry: "28",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "76",
					cy: "58",
					rx: "20",
					ry: "26",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "76",
					cy: "58",
					r: "10",
					fill: "#C2663A"
				})
			]
		});
		case "oats": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "78",
					rx: "36",
					ry: "14",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "70",
					rx: "32",
					ry: "22",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "46",
					cy: "66",
					r: "6",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "62",
					cy: "60",
					r: "5",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "74",
					cy: "68",
					r: "6",
					fill: "#5F6E32"
				})
			]
		});
		case "toast": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "28",
					y: "30",
					width: "64",
					height: "60",
					rx: "14",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "34",
					y: "36",
					width: "52",
					height: "48",
					rx: "10",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "12",
					fill: "#5F6E32"
				})
			]
		});
		case "yogurt": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "34",
					y: "38",
					width: "52",
					height: "48",
					rx: "12",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "42",
					rx: "26",
					ry: "10",
					fill: "#E4D9C8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "52",
					cy: "40",
					r: "6",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "66",
					cy: "38",
					r: "5",
					fill: "#5F6E32"
				})
			]
		});
		case "omelette": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "64",
					rx: "38",
					ry: "24",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "62",
					rx: "28",
					ry: "16",
					fill: "#C2663A",
					opacity: "0.35"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "60",
					r: "5",
					fill: "#5F6E32"
				})
			]
		});
		case "rice": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "82",
					rx: "34",
					ry: "12",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "64",
					rx: "30",
					ry: "22",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "48",
					r: "14",
					fill: "#C2663A"
				})
			]
		});
		case "pasta": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "26",
					y: "40",
					width: "68",
					height: "44",
					rx: "16",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M34 58c8-8 16 8 24 0s16 8 24 0 16 8 24 0",
					fill: "none",
					stroke: "#C2663A",
					strokeWidth: "5",
					strokeLinecap: "round"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M34 70c8-8 16 8 24 0s16 8 24 0 16 8 24 0",
					fill: "none",
					stroke: "#5F6E32",
					strokeWidth: "5",
					strokeLinecap: "round"
				})
			]
		});
		case "stew": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "78",
					rx: "36",
					ry: "16",
					fill: "#4A5726"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "62",
					rx: "32",
					ry: "20",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "50",
					cy: "60",
					r: "6",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "70",
					cy: "58",
					r: "5",
					fill: "#F6E4D8"
				})
			]
		});
		case "salad": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "78",
					rx: "34",
					ry: "12",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "48",
					cy: "58",
					r: "16",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "72",
					cy: "56",
					r: "14",
					fill: "#4A5726"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "50",
					r: "10",
					fill: "#C2663A"
				})
			]
		});
		case "chicken": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "62",
					cy: "68",
					rx: "28",
					ry: "20",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "44",
					cy: "52",
					r: "14",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "70",
					y: "44",
					width: "10",
					height: "22",
					rx: "5",
					fill: "#5F6E32"
				})
			]
		});
		case "soup": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "80",
					rx: "36",
					ry: "12",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "66",
					rx: "30",
					ry: "16",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M48 44c4-10 20-10 24 0",
					fill: "none",
					stroke: "#8A8276",
					strokeWidth: "3"
				})
			]
		});
		case "fish": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "56",
					cy: "60",
					rx: "28",
					ry: "16",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
					points: "84,60 104,46 104,74",
					fill: "#4A5726"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "42",
					cy: "56",
					r: "3",
					fill: "#FFFBF4"
				})
			]
		});
		case "mushrooms": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "42",
					y: "60",
					width: "12",
					height: "24",
					rx: "6",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "48",
					cy: "56",
					rx: "18",
					ry: "12",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "68",
					y: "64",
					width: "10",
					height: "20",
					rx: "5",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "73",
					cy: "60",
					rx: "14",
					ry: "10",
					fill: "#5F6E32"
				})
			]
		});
		case "smoothie": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M42 36h36l-6 52H48z",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "46",
					y: "28",
					width: "28",
					height: "10",
					rx: "5",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "58",
					y: "18",
					width: "4",
					height: "16",
					rx: "2",
					fill: "#2A261D"
				})
			]
		});
		case "fruit": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "52",
					cy: "64",
					r: "20",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "74",
					cy: "58",
					r: "16",
					fill: "#5F6E32"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "70",
					y: "36",
					width: "6",
					height: "12",
					rx: "3",
					fill: "#4A5726"
				})
			]
		});
		case "cookies": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "46",
					cy: "64",
					r: "18",
					fill: "#C2663A"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "74",
					cy: "56",
					r: "16",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "42",
					cy: "60",
					r: "3",
					fill: "#4A5726"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "52",
					cy: "70",
					r: "3",
					fill: "#4A5726"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "70",
					cy: "52",
					r: "2.5",
					fill: "#5F6E32"
				})
			]
		});
		case "hummus": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "78",
					rx: "34",
					ry: "12",
					fill: "#E4D9C8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "62",
					rx: "28",
					ry: "18",
					fill: "#F6E4D8"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
					cx: "60",
					cy: "60",
					rx: "10",
					ry: "6",
					fill: "#C2663A"
				})
			]
		});
		case "potato": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "60",
				cy: "64",
				rx: "32",
				ry: "22",
				fill: "#C2663A"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "60",
				cy: "64",
				rx: "22",
				ry: "14",
				fill: "#F6E4D8"
			})]
		});
		case "tofu": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "32",
					y: "40",
					width: "56",
					height: "44",
					rx: "10",
					fill: "#FFFBF4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "40",
					y: "48",
					width: "18",
					height: "18",
					rx: "4",
					fill: "#E7EDD4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "62",
					y: "48",
					width: "18",
					height: "18",
					rx: "4",
					fill: "#E7EDD4"
				})
			]
		});
		case "wrap": return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Frame, {
			className,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "60",
				cy: "62",
				rx: "36",
				ry: "22",
				fill: "#F6E4D8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M30 62c12 16 48 16 60 0",
				fill: "#5F6E32"
			})]
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Frame, {
			className,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "60",
				cy: "60",
				r: "22",
				fill: "#5F6E32"
			})
		});
	}
}
//#endregion
export { RecipeIllustration as t };
