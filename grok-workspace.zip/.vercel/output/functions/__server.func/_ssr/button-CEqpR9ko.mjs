import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recipes-Ds__JUoY.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var ADMOB = {
	appId: "ca-app-pub-3940256099942544~3347511713",
	bannerId: "ca-app-pub-3940256099942544/6300978111",
	interstitialId: "ca-app-pub-3940256099942544/1033173712",
	rewardedId: "ca-app-pub-3940256099942544/5224354917"
};
function isTestAdId(id) {
	return id.includes("3940256099942544");
}
var INGREDIENT_GROUPS = [
	{
		id: "basicos",
		label: "Básicos"
	},
	{
		id: "proteinas",
		label: "Proteínas"
	},
	{
		id: "verduras",
		label: "Verduras"
	},
	{
		id: "despensa",
		label: "Despensa"
	},
	{
		id: "lacteos",
		label: "Lácteos"
	},
	{
		id: "frutas",
		label: "Frutas y frutos"
	}
];
var INGREDIENTS = [
	{
		id: "aceite_oliva",
		name: "Aceite de oliva",
		group: "basicos"
	},
	{
		id: "sal",
		name: "Sal",
		group: "basicos"
	},
	{
		id: "pimienta",
		name: "Pimienta",
		group: "basicos"
	},
	{
		id: "ajo",
		name: "Ajo",
		group: "basicos"
	},
	{
		id: "cebolla",
		name: "Cebolla",
		group: "basicos"
	},
	{
		id: "limon",
		name: "Limón",
		group: "basicos"
	},
	{
		id: "vinagre",
		name: "Vinagre",
		group: "basicos"
	},
	{
		id: "agua",
		name: "Agua",
		group: "basicos"
	},
	{
		id: "huevo",
		name: "Huevo",
		group: "proteinas"
	},
	{
		id: "pollo",
		name: "Pollo",
		group: "proteinas"
	},
	{
		id: "atun",
		name: "Atún",
		group: "proteinas"
	},
	{
		id: "salmon",
		name: "Salmón",
		group: "proteinas"
	},
	{
		id: "tofu",
		name: "Tofu",
		group: "proteinas"
	},
	{
		id: "jamon",
		name: "Jamón",
		group: "proteinas"
	},
	{
		id: "carne_picada",
		name: "Carne picada",
		group: "proteinas"
	},
	{
		id: "garbanzos",
		name: "Garbanzos",
		group: "proteinas"
	},
	{
		id: "lentejas",
		name: "Lentejas",
		group: "proteinas"
	},
	{
		id: "tomate",
		name: "Tomate",
		group: "verduras"
	},
	{
		id: "pimiento",
		name: "Pimiento",
		group: "verduras"
	},
	{
		id: "zanahoria",
		name: "Zanahoria",
		group: "verduras"
	},
	{
		id: "patata",
		name: "Patata",
		group: "verduras"
	},
	{
		id: "lechuga",
		name: "Lechuga",
		group: "verduras"
	},
	{
		id: "espinaca",
		name: "Espinaca",
		group: "verduras"
	},
	{
		id: "calabacin",
		name: "Calabacín",
		group: "verduras"
	},
	{
		id: "champinon",
		name: "Champiñón",
		group: "verduras"
	},
	{
		id: "pepino",
		name: "Pepino",
		group: "verduras"
	},
	{
		id: "brocoli",
		name: "Brócoli",
		group: "verduras"
	},
	{
		id: "aguacate",
		name: "Aguacate",
		group: "verduras"
	},
	{
		id: "arroz",
		name: "Arroz",
		group: "despensa"
	},
	{
		id: "pasta",
		name: "Pasta",
		group: "despensa"
	},
	{
		id: "pan",
		name: "Pan",
		group: "despensa"
	},
	{
		id: "harina",
		name: "Harina",
		group: "despensa"
	},
	{
		id: "avena",
		name: "Avena",
		group: "despensa"
	},
	{
		id: "azucar",
		name: "Azúcar",
		group: "despensa"
	},
	{
		id: "miel",
		name: "Miel",
		group: "despensa"
	},
	{
		id: "cacao",
		name: "Cacao",
		group: "despensa"
	},
	{
		id: "cafe",
		name: "Café",
		group: "despensa"
	},
	{
		id: "canela",
		name: "Canela",
		group: "despensa"
	},
	{
		id: "comino",
		name: "Comino",
		group: "despensa"
	},
	{
		id: "pimenton",
		name: "Pimentón",
		group: "despensa"
	},
	{
		id: "chocolate",
		name: "Chocolate",
		group: "despensa"
	},
	{
		id: "yogur",
		name: "Yogur",
		group: "lacteos"
	},
	{
		id: "queso",
		name: "Queso",
		group: "lacteos"
	},
	{
		id: "leche",
		name: "Leche",
		group: "lacteos"
	},
	{
		id: "mantequilla",
		name: "Mantequilla",
		group: "lacteos"
	},
	{
		id: "nata",
		name: "Nata",
		group: "lacteos"
	},
	{
		id: "platano",
		name: "Plátano",
		group: "frutas"
	},
	{
		id: "manzana",
		name: "Manzana",
		group: "frutas"
	},
	{
		id: "fresa",
		name: "Fresa",
		group: "frutas"
	},
	{
		id: "naranja",
		name: "Naranja",
		group: "frutas"
	},
	{
		id: "nueces",
		name: "Nueces",
		group: "frutas"
	},
	{
		id: "almendras",
		name: "Almendras",
		group: "frutas"
	}
];
var INGREDIENT_MAP = new Map(INGREDIENTS.map((item) => [item.id, item]));
function ingredientName(id) {
	return INGREDIENT_MAP.get(id)?.name ?? id;
}
/** Pantry items that never block “puedo hacer ahora”. */
var STAPLE_IDS = /* @__PURE__ */ new Set([
	"sal",
	"pimienta",
	"aceite_oliva",
	"agua"
]);
var DEFAULT_SELECTED = [
	"aceite_oliva",
	"sal",
	"pimienta"
];
var useAppStore = create()(persist((set, get) => ({
	hydrated: false,
	setHydrated: (value) => set({ hydrated: value }),
	ingredientIds: DEFAULT_SELECTED,
	toggleIngredient: (id) => set((state) => ({ ingredientIds: state.ingredientIds.includes(id) ? state.ingredientIds.filter((item) => item !== id) : [...state.ingredientIds, id] })),
	setIngredients: (ids) => set({ ingredientIds: ids }),
	clearIngredients: () => set({ ingredientIds: [] }),
	maxTime: 30,
	setMaxTime: (time) => set({ maxTime: time }),
	category: null,
	setCategory: (category) => set({ category }),
	tags: [],
	toggleTag: (tag) => set((state) => ({ tags: state.tags.includes(tag) ? state.tags.filter((item) => item !== tag) : [...state.tags, tag] })),
	servings: 2,
	setServings: (n) => set({ servings: Math.min(8, Math.max(1, n)) }),
	onlyNow: false,
	setOnlyNow: (value) => set({ onlyNow: value }),
	favorites: [],
	toggleFavorite: (id) => set((state) => ({ favorites: state.favorites.includes(id) ? state.favorites.filter((item) => item !== id) : [...state.favorites, id] })),
	clearFavorites: () => set({ favorites: [] }),
	isFavorite: (id) => get().favorites.includes(id),
	adsDisabled: false,
	setAdsDisabled: (value) => set({ adsDisabled: value }),
	openedRecipeIds: [],
	lastInterstitialAt: 0,
	interstitialVisible: false,
	rewardedVisible: false,
	markRecipeOpened: (id) => set((state) => ({ openedRecipeIds: state.openedRecipeIds.includes(id) ? state.openedRecipeIds : [...state.openedRecipeIds, id] })),
	shouldOfferInterstitial: () => {
		const state = get();
		if (state.adsDisabled) return false;
		if (state.timer.running) return false;
		if (state.openedRecipeIds.length < 5) return false;
		if (Date.now() - state.lastInterstitialAt < 6e5) return false;
		return true;
	},
	showInterstitial: () => set({
		interstitialVisible: true,
		lastInterstitialAt: Date.now()
	}),
	hideInterstitial: () => set({ interstitialVisible: false }),
	showRewarded: () => set({ rewardedVisible: true }),
	hideRewarded: () => set({ rewardedVisible: false }),
	timer: {
		running: false,
		remaining: 0,
		duration: 0,
		recipeId: null
	},
	startTimer: (seconds, recipeId) => set({ timer: {
		running: true,
		remaining: seconds,
		duration: seconds,
		recipeId
	} }),
	pauseTimer: () => set((state) => ({ timer: {
		...state.timer,
		running: false
	} })),
	resumeTimer: () => set((state) => ({ timer: {
		...state.timer,
		running: state.timer.remaining > 0
	} })),
	tickTimer: () => set((state) => {
		if (!state.timer.running) return state;
		const remaining = Math.max(0, state.timer.remaining - 1);
		return { timer: {
			...state.timer,
			remaining,
			running: remaining > 0
		} };
	}),
	resetTimer: () => set({ timer: {
		running: false,
		remaining: 0,
		duration: 0,
		recipeId: null
	} })
}), {
	name: "que-como-hoy",
	skipHydration: true,
	storage: createJSONStorage(() => localStorage),
	partialize: (state) => ({
		ingredientIds: state.ingredientIds,
		maxTime: state.maxTime,
		category: state.category,
		tags: state.tags,
		servings: state.servings,
		onlyNow: state.onlyNow,
		favorites: state.favorites,
		adsDisabled: state.adsDisabled,
		openedRecipeIds: state.openedRecipeIds,
		lastInterstitialAt: state.lastInterstitialAt
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated(true);
	}
}));
var recipes = /* @__PURE__ */ JSON.parse("[{\"id\":\"huevos-revueltos-tomate\",\"name\":\"Huevos revueltos con tomate\",\"category\":\"desayuno\",\"illustration\":\"eggs\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"huevo\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"pimienta\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Lava y trocea los tomates en dados pequeños.\",\"Calienta el aceite en una sartén y sofríe el tomate 3 minutos hasta que suelte jugo.\",\"Bate los huevos con sal y pimienta, viértelos sobre el tomate y remueve a fuego medio.\",\"Retira cuando estén cremosos y sirve al momento.\"],\"calories\":240,\"difficulty\":\"facil\"},{\"id\":\"avena-platano-miel\",\"name\":\"Avena con plátano y miel\",\"category\":\"desayuno\",\"illustration\":\"oats\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"avena\",\"amount\":50,\"unit\":\"g\"},{\"id\":\"leche\",\"amount\":200,\"unit\":\"ml\"},{\"id\":\"platano\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Calienta la leche en un cazo a fuego medio.\",\"Añade la avena y cocina 4 minutos removiendo.\",\"Sirve en un bol, cubre con el plátano en rodajas y un hilo de miel.\"],\"calories\":320,\"difficulty\":\"facil\"},{\"id\":\"tostada-aguacate-huevo\",\"name\":\"Tostada de aguacate y huevo\",\"category\":\"desayuno\",\"illustration\":\"toast\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"pan\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aguacate\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"huevo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"limon\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"alto_proteina\"],\"steps\":[\"Tuesta el pan hasta que esté crujiente.\",\"Machaca el aguacate con sal y unas gotas de limón.\",\"Escala o fríe el huevo en un chorrito de aceite.\",\"Unta el aguacate sobre el pan y coloca el huevo encima.\"],\"calories\":380,\"difficulty\":\"facil\"},{\"id\":\"yogur-avena-fresa\",\"name\":\"Yogur con avena y fresa\",\"category\":\"desayuno\",\"illustration\":\"yogurt\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"yogur\",\"amount\":200,\"unit\":\"g\"},{\"id\":\"avena\",\"amount\":30,\"unit\":\"g\"},{\"id\":\"fresa\",\"amount\":80,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Lava y trocea las fresas.\",\"Pon el yogur en un bol, añade la avena y mezcla.\",\"Cubre con las fresas y un toque de miel.\"],\"calories\":260,\"difficulty\":\"facil\"},{\"id\":\"tortilla-jamon\",\"name\":\"Tortilla francesa de jamón\",\"category\":\"desayuno\",\"illustration\":\"omelette\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"huevo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"jamon\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Bate los huevos con una pizca de sal.\",\"Trocea el jamón en tiras pequeñas.\",\"Calienta el aceite, vierte el huevo y esparce el jamón.\",\"Dobla la tortilla cuando esté cuajada y sirve.\"],\"calories\":290,\"difficulty\":\"facil\"},{\"id\":\"pan-tomate-aceite\",\"name\":\"Pan con tomate\",\"category\":\"desayuno\",\"illustration\":\"toast\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"pan\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"ajo\",\"amount\":1,\"unit\":\"ud\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Tuesta las rebanadas de pan.\",\"Frota un diente de ajo por la superficie del pan caliente.\",\"Corta el tomate por la mitad y rállalo sobre el pan.\",\"Aliña con aceite y sal.\"],\"calories\":220,\"difficulty\":\"facil\"},{\"id\":\"batido-platano-leche\",\"name\":\"Batido de plátano\",\"category\":\"desayuno\",\"illustration\":\"smoothie\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"platano\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"leche\",\"amount\":250,\"unit\":\"ml\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"canela\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Pela el plátano y córtalo en trozos.\",\"Tritura con la leche y la miel hasta que quede suave.\",\"Sirve con una pizca de canela.\"],\"calories\":250,\"difficulty\":\"facil\"},{\"id\":\"huevos-pimiento\",\"name\":\"Huevos al plato con pimiento\",\"category\":\"desayuno\",\"illustration\":\"eggs\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"huevo\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"pimiento\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Pica el pimiento y la cebolla en tiras finas.\",\"Sofríe en aceite 6 minutos hasta que estén tiernos.\",\"Haz huecos, casca un huevo en cada uno y tapa 4 minutos.\",\"Salpimienta y sirve en la misma sartén.\"],\"calories\":280,\"difficulty\":\"facil\"},{\"id\":\"avena-salada-huevo\",\"name\":\"Avena salada con huevo\",\"category\":\"desayuno\",\"illustration\":\"oats\",\"timeMinutes\":20,\"servings\":1,\"ingredients\":[{\"id\":\"avena\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"agua\",\"amount\":180,\"unit\":\"ml\"},{\"id\":\"huevo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"espinaca\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"alto_proteina\",\"economico\"],\"steps\":[\"Cocina la avena en agua con sal 5 minutos.\",\"Saltea la espinaca en aceite 1 minuto y mézclala con la avena.\",\"Fríe o escala el huevo y colócalo encima.\"],\"calories\":310,\"difficulty\":\"facil\"},{\"id\":\"tostada-queso-miel\",\"name\":\"Tostada de queso y miel\",\"category\":\"desayuno\",\"illustration\":\"toast\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"pan\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"queso\",\"amount\":50,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"nueces\",\"amount\":15,\"unit\":\"g\"}],\"tags\":[\"vegetariano\"],\"steps\":[\"Tuesta el pan.\",\"Coloca láminas de queso sobre el pan caliente para que se ablanden.\",\"Rocía con miel y espolvorea las nueces troceadas.\"],\"calories\":340,\"difficulty\":\"facil\"},{\"id\":\"arroz-tomate-huevo\",\"name\":\"Arroz con tomate y huevo\",\"category\":\"comida\",\"illustration\":\"rice\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"arroz\",\"amount\":160,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"huevo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Enjuaga el arroz y cuécelo en agua con sal 15 minutos. Escúrrelo.\",\"Sofríe el tomate troceado en aceite 8 minutos hasta que espese.\",\"Mezcla el arroz con el tomate.\",\"Fríe los huevos y sírvelos sobre el arroz.\"],\"calories\":430,\"difficulty\":\"facil\"},{\"id\":\"pasta-ajo-aceite\",\"name\":\"Pasta al ajo y aceite\",\"category\":\"comida\",\"illustration\":\"pasta\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"pasta\",\"amount\":180,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"pimienta\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Cuece la pasta en agua abundante con sal el tiempo del paquete.\",\"Lamina el ajo y confítalo a fuego bajo en el aceite sin que se queme.\",\"Escurre la pasta, mezcla con el aceite de ajo y añade pimienta.\"],\"calories\":480,\"difficulty\":\"facil\"},{\"id\":\"garbanzos-espinaca\",\"name\":\"Garbanzos con espinaca\",\"category\":\"comida\",\"illustration\":\"stew\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"garbanzos\",\"amount\":400,\"unit\":\"g\"},{\"id\":\"espinaca\",\"amount\":150,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"pimenton\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Pica el ajo y sofríelo en aceite 1 minuto.\",\"Añade el pimentón, los garbanzos escurridos y un chorrito de agua.\",\"Incorpora la espinaca y cocina 5 minutos hasta que se ablande.\",\"Rectifica de sal y sirve caliente.\"],\"calories\":360,\"difficulty\":\"facil\"},{\"id\":\"lentejas-zanahoria\",\"name\":\"Lentejas con zanahoria\",\"category\":\"comida\",\"illustration\":\"stew\",\"timeMinutes\":45,\"servings\":3,\"ingredients\":[{\"id\":\"lentejas\",\"amount\":250,\"unit\":\"g\"},{\"id\":\"zanahoria\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"comino\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"agua\",\"amount\":800,\"unit\":\"ml\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Pica la cebolla, el ajo y la zanahoria.\",\"Sofríe las verduras en aceite 5 minutos.\",\"Añade las lentejas, el comino, la sal y el agua.\",\"Cuece a fuego medio 35 minutos hasta que estén tiernas.\"],\"calories\":340,\"difficulty\":\"media\"},{\"id\":\"pollo-limon-arroz\",\"name\":\"Pollo al limón con arroz\",\"category\":\"comida\",\"illustration\":\"chicken\",\"timeMinutes\":45,\"servings\":2,\"ingredients\":[{\"id\":\"pollo\",\"amount\":400,\"unit\":\"g\"},{\"id\":\"arroz\",\"amount\":150,\"unit\":\"g\"},{\"id\":\"limon\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"pimienta\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Salpimienta el pollo y dóralo en aceite 4 minutos por lado.\",\"Añade el ajo laminado y el zumo del limón. Tapa 12 minutos a fuego medio.\",\"Mientras, cuece el arroz en agua con sal.\",\"Sirve el pollo con su jugo sobre el arroz.\"],\"calories\":520,\"difficulty\":\"media\"},{\"id\":\"ensalada-atun-tomate\",\"name\":\"Ensalada de atún y tomate\",\"category\":\"comida\",\"illustration\":\"salad\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"atun\",\"amount\":160,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"lechuga\",\"amount\":100,\"unit\":\"g\"},{\"id\":\"cebolla\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"vinagre\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Lava la lechuga y el tomate. Trocea.\",\"Corta la cebolla en juliana fina.\",\"Escurre el atún y mézclalo con las verduras.\",\"Aliña con aceite, vinagre y sal.\"],\"calories\":280,\"difficulty\":\"facil\"},{\"id\":\"arroz-pollo-pimiento\",\"name\":\"Arroz con pollo y pimiento\",\"category\":\"comida\",\"illustration\":\"rice\",\"timeMinutes\":45,\"servings\":3,\"ingredients\":[{\"id\":\"arroz\",\"amount\":240,\"unit\":\"g\"},{\"id\":\"pollo\",\"amount\":350,\"unit\":\"g\"},{\"id\":\"pimiento\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"agua\",\"amount\":600,\"unit\":\"ml\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Dora el pollo troceado en aceite. Reserva.\",\"Sofríe ajo, pimiento y tomate 6 minutos.\",\"Añade el arroz, el pollo, el agua y la sal.\",\"Cuece 18 minutos a fuego medio-bajo sin remover.\"],\"calories\":490,\"difficulty\":\"media\"},{\"id\":\"pasta-tomate-queso\",\"name\":\"Pasta con tomate y queso\",\"category\":\"comida\",\"illustration\":\"pasta\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"pasta\",\"amount\":180,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"queso\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Cuece la pasta en agua con sal.\",\"Sofríe el ajo, añade el tomate troceado y cocina 12 minutos.\",\"Mezcla la pasta con la salsa y ralla el queso por encima.\"],\"calories\":510,\"difficulty\":\"facil\"},{\"id\":\"tortilla-patata\",\"name\":\"Tortilla de patata\",\"category\":\"comida\",\"illustration\":\"potato\",\"timeMinutes\":45,\"servings\":4,\"ingredients\":[{\"id\":\"huevo\",\"amount\":6,\"unit\":\"ud\"},{\"id\":\"patata\",\"amount\":600,\"unit\":\"g\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":80,\"unit\":\"ml\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Pela y lamina las patatas. Pica la cebolla.\",\"Confitúalas en aceite a fuego medio 20 minutos. Escurre.\",\"Bate los huevos con sal, mezcla con la patata y deja reposar 3 minutos.\",\"Cuaja en una sartén 4 minutos por cada lado, ayudándote de un plato para girar.\"],\"calories\":390,\"difficulty\":\"avanzada\"},{\"id\":\"salteado-verduras-arroz\",\"name\":\"Salteado de verduras con arroz\",\"category\":\"comida\",\"illustration\":\"rice\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"arroz\",\"amount\":150,\"unit\":\"g\"},{\"id\":\"calabacin\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"pimiento\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"zanahoria\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Cuece el arroz y reserva.\",\"Corta las verduras en dados regulares.\",\"Saltea el ajo y las verduras 8 minutos a fuego fuerte.\",\"Mezcla con el arroz, salpimienta y sirve.\"],\"calories\":370,\"difficulty\":\"facil\"},{\"id\":\"garbanzos-tomate-pimenton\",\"name\":\"Garbanzos con tomate\",\"category\":\"comida\",\"illustration\":\"stew\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"garbanzos\",\"amount\":400,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"pimenton\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"comino\",\"amount\":0.5,\"unit\":\"cdta\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Sofríe la cebolla picada en aceite 5 minutos.\",\"Añade el tomate troceado, el pimentón y el comino. Cocina 8 minutos.\",\"Incorpora los garbanzos y deja que tomen el sabor 8 minutos más.\"],\"calories\":350,\"difficulty\":\"facil\"},{\"id\":\"pollo-patata-horno\",\"name\":\"Pollo y patata al horno\",\"category\":\"comida\",\"illustration\":\"chicken\",\"timeMinutes\":45,\"servings\":3,\"ingredients\":[{\"id\":\"pollo\",\"amount\":500,\"unit\":\"g\"},{\"id\":\"patata\",\"amount\":500,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"pimenton\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"aceite_oliva\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"limon\",\"amount\":0.5,\"unit\":\"ud\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Precalienta el horno a 200 °C.\",\"Corta las patatas en gajos y el pollo en trozos.\",\"Mezcla con aceite, ajo, pimentón, sal y limón.\",\"Hornea 40 minutos, removiendo a mitad de cocción.\"],\"calories\":480,\"difficulty\":\"media\"},{\"id\":\"ensalada-lentejas\",\"name\":\"Ensalada de lentejas\",\"category\":\"comida\",\"illustration\":\"salad\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"lentejas\",\"amount\":250,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"pepino\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"vinagre\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Si usas lentejas cocidas, escúrrelas. Si son crudas, cuécelas 20 minutos.\",\"Trocea tomate, pepino y cebolla.\",\"Mezcla con las lentejas y aliña.\"],\"calories\":310,\"difficulty\":\"facil\"},{\"id\":\"pasta-calabacin\",\"name\":\"Pasta con calabacín\",\"category\":\"comida\",\"illustration\":\"pasta\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"pasta\",\"amount\":180,\"unit\":\"g\"},{\"id\":\"calabacin\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"queso\",\"amount\":30,\"unit\":\"g\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Cuece la pasta.\",\"Saltea el ajo y el calabacín en dados 7 minutos.\",\"Mezcla con la pasta y el queso rallado.\"],\"calories\":470,\"difficulty\":\"facil\"},{\"id\":\"sopa-tomate-ajo\",\"name\":\"Sopa de tomate y ajo\",\"category\":\"cena\",\"illustration\":\"soup\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"tomate\",\"amount\":5,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"agua\",\"amount\":400,\"unit\":\"ml\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Sofríe cebolla y ajo 5 minutos.\",\"Añade el tomate troceado y cocina 10 minutos.\",\"Suma el agua, tritura y hierve 5 minutos más. Salpimienta.\"],\"calories\":160,\"difficulty\":\"facil\"},{\"id\":\"tortilla-espinaca\",\"name\":\"Tortilla de espinaca\",\"category\":\"cena\",\"illustration\":\"omelette\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"huevo\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"espinaca\",\"amount\":120,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Saltea el ajo y la espinaca 2 minutos. Deja enfriar un poco.\",\"Bate los huevos con sal y mezcla con la espinaca.\",\"Cuaja la tortilla 3 minutos por lado.\"],\"calories\":270,\"difficulty\":\"facil\"},{\"id\":\"salmon-limon\",\"name\":\"Salmón a la plancha\",\"category\":\"cena\",\"illustration\":\"fish\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"salmon\",\"amount\":300,\"unit\":\"g\"},{\"id\":\"limon\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"pimienta\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Seca el salmón y salpimienta.\",\"Calienta una sartén con aceite y cocina 4 minutos por el lado de la piel.\",\"Gira 3 minutos más. Sirve con gajos de limón.\"],\"calories\":410,\"difficulty\":\"media\"},{\"id\":\"ensalada-aguacate\",\"name\":\"Ensalada de lechuga y aguacate\",\"category\":\"cena\",\"illustration\":\"salad\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"lechuga\",\"amount\":120,\"unit\":\"g\"},{\"id\":\"aguacate\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"tomate\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"pepino\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"limon\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Lava y trocea la lechuga, el tomate y el pepino.\",\"Añade el aguacate en dados.\",\"Aliña con aceite, limón y sal justo antes de servir.\"],\"calories\":240,\"difficulty\":\"facil\"},{\"id\":\"champinones-ajillo\",\"name\":\"Champiñones al ajillo\",\"category\":\"cena\",\"illustration\":\"mushrooms\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"champinon\",\"amount\":300,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"pimienta\",\"amount\":1,\"unit\":\"pizca\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Limpia los champiñones y córtalos por la mitad.\",\"Calienta el aceite con el ajo laminado.\",\"Saltea los champiñones 8 minutos a fuego medio-alto.\",\"Salpimienta y sirve con pan si quieres.\"],\"calories\":180,\"difficulty\":\"facil\"},{\"id\":\"calabacin-queso\",\"name\":\"Calabacín al horno con queso\",\"category\":\"cena\",\"illustration\":\"potato\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"calabacin\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"queso\",\"amount\":80,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"pimenton\",\"amount\":0.5,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Precalienta el horno a 200 °C.\",\"Corta el calabacín en rodajas, aliña con aceite, ajo y sal.\",\"Cubre con queso y pimentón. Hornea 18 minutos.\"],\"calories\":260,\"difficulty\":\"facil\"},{\"id\":\"atun-pimiento\",\"name\":\"Atún con pimiento\",\"category\":\"cena\",\"illustration\":\"fish\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"atun\",\"amount\":200,\"unit\":\"g\"},{\"id\":\"pimiento\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Saltea pimiento y cebolla en tiras 8 minutos.\",\"Añade el atún escurrido, mezcla 2 minutos y sirve.\"],\"calories\":250,\"difficulty\":\"facil\"},{\"id\":\"huevos-espinaca-ajo\",\"name\":\"Huevos con espinaca\",\"category\":\"cena\",\"illustration\":\"eggs\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"huevo\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"espinaca\",\"amount\":150,\"unit\":\"g\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"pimenton\",\"amount\":0.5,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Saltea el ajo y la espinaca 3 minutos.\",\"Haz huecos, casca los huevos y tapa 4 minutos.\",\"Espolvorea pimentón y sal.\"],\"calories\":290,\"difficulty\":\"facil\"},{\"id\":\"crema-zanahoria\",\"name\":\"Crema de zanahoria\",\"category\":\"cena\",\"illustration\":\"soup\",\"timeMinutes\":30,\"servings\":3,\"ingredients\":[{\"id\":\"zanahoria\",\"amount\":500,\"unit\":\"g\"},{\"id\":\"cebolla\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"patata\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"agua\",\"amount\":700,\"unit\":\"ml\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Pica cebolla, zanahoria y patata.\",\"Sofríe la cebolla, añade el resto y cubre con agua.\",\"Cuece 20 minutos y tritura hasta que quede seda.\"],\"calories\":170,\"difficulty\":\"facil\"},{\"id\":\"tofu-verduras\",\"name\":\"Tofu salteado con verduras\",\"category\":\"cena\",\"illustration\":\"tofu\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"tofu\",\"amount\":250,\"unit\":\"g\"},{\"id\":\"brocoli\",\"amount\":150,\"unit\":\"g\"},{\"id\":\"pimiento\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Prensa el tofu y córtalo en dados. Dóralo 5 minutos.\",\"Saltea ajo, brócoli y pimiento 6 minutos.\",\"Junta el tofu, salpimienta y sirve.\"],\"calories\":320,\"difficulty\":\"facil\"},{\"id\":\"wrap-pollo-lechuga\",\"name\":\"Wrap de pollo y lechuga\",\"category\":\"cena\",\"illustration\":\"wrap\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"pollo\",\"amount\":250,\"unit\":\"g\"},{\"id\":\"pan\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"lechuga\",\"amount\":60,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"yogur\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"alto_proteina\"],\"steps\":[\"Salpimienta el pollo y cocínalo a la plancha 6 minutos por lado. Trocea.\",\"Unta el pan con yogur, añade lechuga, tomate y pollo.\",\"Enrolla bien y corta por la mitad.\"],\"calories\":420,\"difficulty\":\"facil\"},{\"id\":\"patatas-pimenton\",\"name\":\"Patatas al pimentón\",\"category\":\"cena\",\"illustration\":\"potato\",\"timeMinutes\":45,\"servings\":3,\"ingredients\":[{\"id\":\"patata\",\"amount\":700,\"unit\":\"g\"},{\"id\":\"pimenton\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"ajo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Precalienta el horno a 200 °C.\",\"Corta las patatas en gajos y mézclalas con aceite, ajo, pimentón y sal.\",\"Hornea 40 minutos hasta que estén doradas.\"],\"calories\":280,\"difficulty\":\"facil\"},{\"id\":\"platano-chocolate-miel\",\"name\":\"Plátano con chocolate\",\"category\":\"postre\",\"illustration\":\"fruit\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"platano\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"chocolate\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\"],\"steps\":[\"Corta los plátanos en rodajas y colócalos en dos platos.\",\"Derrite el chocolate al baño maría o a microondas cortos.\",\"Rocía el chocolate y un hilo de miel.\"],\"calories\":220,\"difficulty\":\"facil\"},{\"id\":\"yogur-miel-nueces\",\"name\":\"Yogur con miel y nueces\",\"category\":\"postre\",\"illustration\":\"yogurt\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"yogur\",\"amount\":200,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"nueces\",\"amount\":20,\"unit\":\"g\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Sirve el yogur en un bol.\",\"Añade la miel y las nueces groseramente picadas.\"],\"calories\":280,\"difficulty\":\"facil\"},{\"id\":\"manzana-canela\",\"name\":\"Manzana asada con canela\",\"category\":\"postre\",\"illustration\":\"fruit\",\"timeMinutes\":30,\"servings\":2,\"ingredients\":[{\"id\":\"manzana\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"canela\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"mantequilla\",\"amount\":10,\"unit\":\"g\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Precalienta el horno a 180 °C.\",\"Quita el corazón de las manzanas y colócalas en un recipiente.\",\"Rellena con miel, canela y un poco de mantequilla. Hornea 25 minutos.\"],\"calories\":180,\"difficulty\":\"facil\"},{\"id\":\"batido-fresa\",\"name\":\"Batido de fresa\",\"category\":\"postre\",\"illustration\":\"smoothie\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"fresa\",\"amount\":200,\"unit\":\"g\"},{\"id\":\"leche\",\"amount\":250,\"unit\":\"ml\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Lava las fresas y retira el rabillo.\",\"Tritura con la leche y la miel hasta que quede fino.\",\"Sirve frío.\"],\"calories\":140,\"difficulty\":\"facil\"},{\"id\":\"galletas-avena-miel\",\"name\":\"Galletas de avena y miel\",\"category\":\"postre\",\"illustration\":\"cookies\",\"timeMinutes\":30,\"servings\":8,\"ingredients\":[{\"id\":\"avena\",\"amount\":120,\"unit\":\"g\"},{\"id\":\"harina\",\"amount\":60,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"mantequilla\",\"amount\":40,\"unit\":\"g\"},{\"id\":\"huevo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"canela\",\"amount\":0.5,\"unit\":\"cdta\"}],\"tags\":[\"vegetariano\"],\"steps\":[\"Precalienta el horno a 180 °C.\",\"Mezcla avena, harina, canela, miel, mantequilla blanda y huevo.\",\"Forma 8 montoncitos y hornea 14 minutos hasta el borde dorado.\"],\"calories\":150,\"difficulty\":\"avanzada\"},{\"id\":\"chocolate-caliente\",\"name\":\"Chocolate caliente\",\"category\":\"postre\",\"illustration\":\"smoothie\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"leche\",\"amount\":400,\"unit\":\"ml\"},{\"id\":\"cacao\",\"amount\":2,\"unit\":\"cda\"},{\"id\":\"azucar\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"canela\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Calienta la leche sin que hierva.\",\"Incorpora cacao y azúcar, remueve hasta disolver.\",\"Sirve con una pizca de canela.\"],\"calories\":160,\"difficulty\":\"facil\"},{\"id\":\"fresas-yogur\",\"name\":\"Fresas con yogur\",\"category\":\"postre\",\"illustration\":\"yogurt\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"fresa\",\"amount\":250,\"unit\":\"g\"},{\"id\":\"yogur\",\"amount\":200,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Lava y corta las fresas.\",\"Sírlas con yogur y un hilo de miel.\"],\"calories\":150,\"difficulty\":\"facil\"},{\"id\":\"compota-manzana\",\"name\":\"Compota de manzana\",\"category\":\"postre\",\"illustration\":\"fruit\",\"timeMinutes\":20,\"servings\":3,\"ingredients\":[{\"id\":\"manzana\",\"amount\":4,\"unit\":\"ud\"},{\"id\":\"azucar\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"canela\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"agua\",\"amount\":80,\"unit\":\"ml\"},{\"id\":\"limon\",\"amount\":0.5,\"unit\":\"ud\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Pela y trocea las manzanas.\",\"Cuécelas con agua, azúcar, canela y un chorrito de limón 15 minutos.\",\"Machaca ligeramente y deja templar.\"],\"calories\":120,\"difficulty\":\"facil\"},{\"id\":\"hummus-garbanzos\",\"name\":\"Hummus casero\",\"category\":\"snack\",\"illustration\":\"hummus\",\"timeMinutes\":10,\"servings\":4,\"ingredients\":[{\"id\":\"garbanzos\",\"amount\":400,\"unit\":\"g\"},{\"id\":\"limon\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":3,\"unit\":\"cda\"},{\"id\":\"comino\",\"amount\":0.5,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Escurre los garbanzos y reserva un poco de su líquido.\",\"Tritura con ajo, limón, comino, sal y aceite.\",\"Ajusta la textura con el líquido reservado. Sirve con un hilo de aceite.\"],\"calories\":180,\"difficulty\":\"facil\"},{\"id\":\"zanahoria-yogur\",\"name\":\"Zanahoria con yogur\",\"category\":\"snack\",\"illustration\":\"salad\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"zanahoria\",\"amount\":3,\"unit\":\"ud\"},{\"id\":\"yogur\",\"amount\":120,\"unit\":\"g\"},{\"id\":\"limon\",\"amount\":0.5,\"unit\":\"ud\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"economico\"],\"steps\":[\"Pela las zanahorias y córtalas en palitos.\",\"Mezcla el yogur con limón y sal. Sirve como dip.\"],\"calories\":90,\"difficulty\":\"facil\"},{\"id\":\"tostada-tomate-ajo\",\"name\":\"Tostada de tomate y ajo\",\"category\":\"snack\",\"illustration\":\"toast\",\"timeMinutes\":10,\"servings\":1,\"ingredients\":[{\"id\":\"pan\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"tomate\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"ajo\",\"amount\":1,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"economico\"],\"steps\":[\"Tuesta el pan y frótalo con ajo.\",\"Cubre con tomate en dados, aceite y sal.\"],\"calories\":190,\"difficulty\":\"facil\"},{\"id\":\"almendras-miel\",\"name\":\"Almendras tostadas con miel\",\"category\":\"snack\",\"illustration\":\"cookies\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"almendras\",\"amount\":60,\"unit\":\"g\"},{\"id\":\"miel\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\"],\"steps\":[\"Tuesta las almendras en una sartén seca 3 minutos.\",\"Añade la miel y una pizca de sal. Remueve 1 minuto y deja enfriar.\"],\"calories\":220,\"difficulty\":\"facil\"},{\"id\":\"huevo-pimenton\",\"name\":\"Huevo duro con pimentón\",\"category\":\"snack\",\"illustration\":\"eggs\",\"timeMinutes\":20,\"servings\":2,\"ingredients\":[{\"id\":\"huevo\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"pimenton\",\"amount\":0.5,\"unit\":\"cdta\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cdta\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\",\"economico\"],\"steps\":[\"Cuece los huevos 10 minutos. Enfría y pela.\",\"Pártelos por la mitad, aliña con aceite, sal y pimentón.\"],\"calories\":160,\"difficulty\":\"facil\"},{\"id\":\"queso-tomate-alinado\",\"name\":\"Queso con tomate aliñado\",\"category\":\"snack\",\"illustration\":\"salad\",\"timeMinutes\":10,\"servings\":2,\"ingredients\":[{\"id\":\"queso\",\"amount\":100,\"unit\":\"g\"},{\"id\":\"tomate\",\"amount\":2,\"unit\":\"ud\"},{\"id\":\"aceite_oliva\",\"amount\":1,\"unit\":\"cda\"},{\"id\":\"sal\",\"amount\":1,\"unit\":\"pizca\"}],\"tags\":[\"vegetariano\",\"sin_gluten\",\"alto_proteina\"],\"steps\":[\"Corta el queso y el tomate en dados.\",\"Aliña con aceite y sal. Mezcla con cuidado.\"],\"calories\":230,\"difficulty\":\"facil\"}]");
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/button-CEqpR9ko.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-semibold transition-[transform,background-color,color,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-olive", {
	variants: {
		variant: {
			primary: "bg-olive text-surface hover:bg-olive-deep",
			secondary: "bg-olive-soft text-olive-deep hover:bg-olive/20",
			ghost: "bg-transparent text-ink hover:bg-surface-2",
			terra: "bg-terra text-surface hover:bg-terra/90",
			outline: "bg-surface text-ink shadow-[var(--shadow-card)]"
		},
		size: {
			md: "h-12 rounded-[16px] px-5 text-base",
			lg: "h-14 rounded-[20px] px-6 text-lg",
			sm: "h-10 rounded-[12px] px-3.5 text-sm",
			icon: "size-11 rounded-full"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { STAPLE_IDS as a, isTestAdId as c, INGREDIENT_GROUPS as i, recipes as l, ADMOB as n, cn as o, INGREDIENTS as r, ingredientName as s, Button as t, useAppStore as u };
