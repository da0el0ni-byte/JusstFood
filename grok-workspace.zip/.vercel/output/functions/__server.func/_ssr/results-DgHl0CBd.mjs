import { J as require_jsx_runtime, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as isTestAdId, n as ADMOB, o as cn, u as useAppStore } from "./button-CEqpR9ko.mjs";
import { _ as ChevronLeft, h as Gift } from "../_libs/lucide-react.mjs";
import { o as searchRecipes } from "./router-B_YNREyx.mjs";
import { t as RecipeCard } from "./RecipeCard-BgsKDekC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-DgHl0CBd.js
var import_jsx_runtime = require_jsx_runtime();
function AdBanner() {
	if (useAppStore((s) => s.adsDisabled)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
		className: "border-t border-line bg-surface-2",
		style: { minHeight: 64 },
		"aria-label": "Espacio de anuncio",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-16 items-center justify-center gap-3 px-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-sm bg-ink px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-surface",
					children: "Anuncio"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-xs font-semibold text-ink-soft",
						children: "Anuncio de prueba AdMob"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate font-mono text-[10px] text-muted",
						children: ADMOB.bannerId
					})]
				}),
				isTestAdId(ADMOB.bannerId) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-[10px] font-semibold uppercase text-terra",
					children: "Test"
				}) : null
			]
		})
	});
}
function ResultsPage() {
	const navigate = useNavigate();
	const ingredientIds = useAppStore((s) => s.ingredientIds);
	const maxTime = useAppStore((s) => s.maxTime);
	const category = useAppStore((s) => s.category);
	const tags = useAppStore((s) => s.tags);
	const onlyNow = useAppStore((s) => s.onlyNow);
	const setOnlyNow = useAppStore((s) => s.setOnlyNow);
	const adsDisabled = useAppStore((s) => s.adsDisabled);
	const showRewarded = useAppStore((s) => s.showRewarded);
	const results = searchRecipes({
		ingredientIds,
		maxTime,
		category,
		tags,
		onlyNow
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center gap-2 bg-bg/95 px-3 py-3 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "flex size-11 items-center justify-center rounded-full",
					onClick: () => void navigate({ to: "/" }),
					"aria-label": "Volver",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl leading-none text-ink",
					children: "Recetas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [results.length, " coincidencias"]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setOnlyNow(!onlyNow),
					className: cn("flex h-12 w-full items-center justify-between rounded-[20px] px-4 text-sm font-semibold", onlyNow ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
					children: ["Solo recetas que puedo hacer ahora", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("text-xs font-bold", onlyNow ? "text-surface" : "text-olive"),
						children: onlyNow ? "Sí" : "No"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-1 flex-col gap-3 px-5 pb-4",
				children: [results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl text-ink",
						children: "Ninguna receta encaja"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-ink-soft",
						children: "Prueba a añadir más ingredientes o desactiva el filtro de “solo ahora”."
					})]
				}) : results.map((scored) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeCard, { scored }, scored.recipe.id)), !adsDisabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: showRewarded,
					className: "mt-2 flex items-start gap-3 rounded-[28px] bg-olive-soft p-4 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "mt-0.5 size-5 shrink-0 text-olive-deep" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-display text-lg text-olive-deep",
						children: "Receta sorpresa"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-ink-soft",
						children: "Opcional: mira un anuncio de prueba y te mostramos una receta al azar."
					})] })]
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdBanner, {})
		]
	});
}
//#endregion
export { ResultsPage as component };
