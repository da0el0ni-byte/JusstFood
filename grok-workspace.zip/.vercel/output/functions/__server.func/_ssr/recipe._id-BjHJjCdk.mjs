import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as STAPLE_IDS, o as cn, s as ingredientName, u as useAppStore } from "./button-CEqpR9ko.mjs";
import { _ as ChevronLeft, g as Clock, m as Heart, r as Users } from "../_libs/lucide-react.mjs";
import { a as scoreRecipe, i as getRecipeById, n as Route, r as RecipeTimer } from "./router-B_YNREyx.mjs";
import { t as RecipeIllustration } from "./RecipeIllustration-BcuBo4if.mjs";
import { i as formatAmount, n as DIFFICULTY_LABEL, o as scaleAmount, r as TAG_LABEL, t as CATEGORY_LABEL } from "./format-D7jV-Z6e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recipe._id-BjHJjCdk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RecipeDetailPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const recipe = getRecipeById(id);
	const ingredientIds = useAppStore((s) => s.ingredientIds);
	const servings = useAppStore((s) => s.servings);
	const favorite = useAppStore((s) => s.favorites.includes(id));
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	const markRecipeOpened = useAppStore((s) => s.markRecipeOpened);
	const shouldOfferInterstitial = useAppStore((s) => s.shouldOfferInterstitial);
	const showInterstitial = useAppStore((s) => s.showInterstitial);
	const timerRunning = useAppStore((s) => s.timer.running);
	(0, import_react.useEffect)(() => {
		if (recipe) markRecipeOpened(recipe.id);
	}, [recipe, markRecipeOpened]);
	if (!recipe) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "px-5 py-10 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl",
			children: "Receta no encontrada"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "mt-4 font-semibold text-olive",
			onClick: () => void navigate({ to: "/" }),
			children: "Volver al inicio"
		})]
	});
	const scored = scoreRecipe(recipe, new Set(ingredientIds));
	const missingIds = new Set(scored.missing.map((item) => item.id));
	function goBack() {
		if (!timerRunning && shouldOfferInterstitial()) showInterstitial();
		navigate({ to: "/results" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex items-center justify-between bg-bg/95 px-3 py-3 backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-full",
						onClick: goBack,
						"aria-label": "Volver",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-olive",
						children: CATEGORY_LABEL[recipe.category]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: cn("flex size-11 items-center justify-center rounded-full", favorite ? "text-terra" : "text-muted"),
						"aria-label": favorite ? "Quitar de favoritos" : "Guardar en favoritos",
						onClick: () => toggleFavorite(recipe.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
							className: "size-5",
							fill: favorite ? "currentColor" : "none"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto size-36 overflow-hidden rounded-[32px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeIllustration, { kind: recipe.illustration })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 text-center font-display text-3xl leading-tight text-ink",
						children: recipe.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap justify-center gap-2 text-sm text-ink-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex h-9 items-center gap-1 rounded-full bg-surface px-3 shadow-[var(--shadow-card)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }),
									" ",
									recipe.timeMinutes,
									" min"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex h-9 items-center gap-1 rounded-full bg-surface px-3 shadow-[var(--shadow-card)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3.5" }),
									" ",
									servings,
									" ",
									servings === 1 ? "persona" : "personas"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex h-9 items-center rounded-full bg-surface px-3 shadow-[var(--shadow-card)]",
								children: DIFFICULTY_LABEL[recipe.difficulty]
							}),
							recipe.calories ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex h-9 items-center rounded-full bg-surface px-3 shadow-[var(--shadow-card)]",
								children: [recipe.calories, " kcal aprox."]
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap justify-center gap-2",
						children: recipe.tags.map((tag) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-olive-soft px-3 py-1 text-xs font-semibold text-olive-deep",
							children: TAG_LABEL[tag]
						}, tag))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl text-ink",
					children: "Ingredientes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: recipe.ingredients.map((item) => {
						const missing = missingIds.has(item.id);
						const staple = STAPLE_IDS.has(item.id);
						const amount = scaleAmount(item.amount, recipe.servings, servings);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("flex items-center justify-between rounded-[16px] px-3 py-3", missing ? "bg-terra-soft" : "bg-surface shadow-[var(--shadow-card)]"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold text-ink",
								children: [ingredientName(item.id), missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs font-bold text-terra",
									children: "Falta"
								}) : staple ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-2 text-xs font-bold text-good",
									children: "Lo tienes"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm text-ink-soft",
								children: formatAmount(amount, item.unit)
							})]
						}, item.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8 px-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl text-ink",
					children: "Pasos"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-3 space-y-3",
					children: recipe.steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3 rounded-[20px] bg-surface p-3 shadow-[var(--shadow-card)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-8 shrink-0 items-center justify-center rounded-full bg-olive font-display text-sm text-surface",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-1 text-base leading-relaxed text-ink",
							children: step
						})]
					}, step))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 px-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeTimer, {
					recipeId: recipe.id,
					defaultMinutes: recipe.timeMinutes
				})
			})
		]
	});
}
//#endregion
export { RecipeDetailPage as component };
