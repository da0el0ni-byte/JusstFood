import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as recipes, n as ADMOB, o as cn, t as Button, u as useAppStore } from "./button-CEqpR9ko.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CTMMPXGG.js
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const favorites = useAppStore((s) => s.favorites);
	const clearFavorites = useAppStore((s) => s.clearFavorites);
	const adsDisabled = useAppStore((s) => s.adsDisabled);
	const setAdsDisabled = useAppStore((s) => s.setAdsDisabled);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pt-8 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-ink",
				children: "Ajustes"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Datos en el dispositivo"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-ink-soft",
						children: [
							"Tienes ",
							favorites.length,
							" recetas favoritas guardadas."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4 w-full",
						variant: "terra",
						onClick: clearFavorites,
						disabled: favorites.length === 0,
						children: "Borrar favoritos"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Anuncios"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed text-ink-soft",
						children: "Ahora mismo se usan IDs de prueba de Google AdMob. Antes de publicar, sustituye los IDs en el archivo de configuración de anuncios."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setAdsDisabled(!adsDisabled),
						className: cn("mt-4 flex h-12 w-full items-center justify-between rounded-[16px] px-4 text-sm font-semibold", adsDisabled || false ? "bg-olive text-surface" : "bg-olive-soft text-olive-deep"),
						children: ["Desactivar anuncios (desarrollo)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: adsDisabled || false ? "Sí" : "No" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-1 font-mono text-[10px] leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Banner ", ADMOB.bannerId] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Intersticial ", ADMOB.interstitialId] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["Recompensado ", ADMOB.rewardedId] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-4 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Acerca de"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm leading-relaxed text-ink-soft",
						children: [
							"¿Qué como hoy? te ayuda a decidir qué cocinar con lo que ya tienes. ",
							recipes.length,
							" recetas originales, sin cuenta y sin conexión."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Versión 1.0"
					})
				]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
