import { i as __toESM } from "../_runtime.mjs";
import { J as require_jsx_runtime, Y as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as INGREDIENT_GROUPS, o as cn, r as INGREDIENTS, t as Button, u as useAppStore } from "./button-CEqpR9ko.mjs";
import { c as Search, f as Leaf, i as UserRound, n as Wallet, s as Shield, t as X } from "../_libs/lucide-react.mjs";
import { o as searchRecipes } from "./router-B_YNREyx.mjs";
import { r as TAG_LABEL, t as CATEGORY_LABEL } from "./format-D7jV-Z6e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DSCvZnOs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IngredientPicker() {
	const selected = useAppStore((s) => s.ingredientIds);
	const toggle = useAppStore((s) => s.toggleIngredient);
	const clear = useAppStore((s) => s.clearIngredients);
	const [query, setQuery] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		if (!q) return INGREDIENTS;
		return INGREDIENTS.filter((item) => item.name.toLowerCase().includes(q));
	}, [query]);
	const selectedSet = new Set(selected);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-ink",
				children: "Qué tienes"
			}), selected.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "h-11 text-sm font-semibold text-olive",
				onClick: clear,
				children: "Limpiar"
			}) : null]
		}),
		selected.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 flex gap-2 overflow-x-auto pb-1",
			children: selected.map((id) => {
				const item = INGREDIENTS.find((ing) => ing.id === id);
				if (!item) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => toggle(id),
					className: "inline-flex h-10 shrink-0 items-center gap-1 rounded-full bg-olive px-3 text-sm font-semibold text-surface",
					children: [item.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })]
				}, id);
			})
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-3 flex h-12 items-center gap-2 rounded-[16px] bg-surface px-3 shadow-[var(--shadow-card)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Buscar ingrediente",
				className: "h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 space-y-4",
			children: INGREDIENT_GROUPS.map((group) => {
				const items = filtered.filter((item) => item.group === group.id);
				if (items.length === 0) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-semibold uppercase tracking-wide text-muted",
					children: group.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: items.map((item) => {
						const on = selectedSet.has(item.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => toggle(item.id),
							className: cn("h-11 rounded-full px-3.5 text-sm font-semibold transition-colors duration-150", on ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
							children: item.name
						}, item.id);
					})
				})] }, group.id);
			})
		})
	] });
}
var CATEGORIES = [
	"desayuno",
	"comida",
	"cena",
	"postre",
	"snack"
];
var TIME_OPTIONS = [
	10,
	20,
	30,
	45
];
var TAG_META = [
	{
		id: "vegetariano",
		icon: Leaf
	},
	{
		id: "sin_gluten",
		icon: Shield
	},
	{
		id: "alto_proteina",
		icon: UserRound
	},
	{
		id: "economico",
		icon: Wallet
	}
];
function Home() {
	const navigate = useNavigate();
	const ingredientIds = useAppStore((s) => s.ingredientIds);
	const maxTime = useAppStore((s) => s.maxTime);
	const setMaxTime = useAppStore((s) => s.setMaxTime);
	const category = useAppStore((s) => s.category);
	const setCategory = useAppStore((s) => s.setCategory);
	const tags = useAppStore((s) => s.tags);
	const toggleTag = useAppStore((s) => s.toggleTag);
	const servings = useAppStore((s) => s.servings);
	const setServings = useAppStore((s) => s.setServings);
	const previewCount = searchRecipes({
		ingredientIds,
		maxTime,
		category,
		tags,
		onlyNow: false
	}).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex flex-1 flex-col px-5 pt-8 pb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "stagger-in",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold uppercase tracking-[0.18em] text-olive",
						children: "Cocina de casa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-[2.15rem] leading-[1.1] tracking-tight text-ink",
						children: "¿Qué como hoy?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-[22ch] text-base leading-relaxed text-ink-soft",
						children: "Elige lo que tienes y te decimos qué puedes cocinar."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-7",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IngredientPicker, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl text-ink",
					children: "Tiempo máximo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-4 gap-2",
					children: TIME_OPTIONS.map((time) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setMaxTime(time),
						className: cn("h-12 rounded-[16px] text-sm font-bold transition-colors duration-150", maxTime === time ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
						children: [time, "’"]
					}, time))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl text-ink",
					children: "Tipo de comida"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCategory(null),
						className: cn("h-11 rounded-full px-4 text-sm font-semibold", category === null ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
						children: "Todas"
					}), CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCategory(item),
						className: cn("h-11 rounded-full px-4 text-sm font-semibold", category === item ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
						children: CATEGORY_LABEL[item]
					}, item))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl text-ink",
						children: "Preferencias"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Opcional"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-2 gap-2",
						children: TAG_META.map(({ id, icon: Icon }) => {
							const on = tags.includes(id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => toggleTag(id),
								className: cn("flex h-14 items-center gap-2 rounded-[20px] px-3 text-left text-sm font-semibold", on ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), TAG_LABEL[id]]
							}, id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl text-ink",
					children: "Personas"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-12 items-center justify-center rounded-[16px] bg-surface text-2xl font-semibold shadow-[var(--shadow-card)]",
							onClick: () => setServings(servings - 1),
							"aria-label": "Menos personas",
							children: "−"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-10 text-center font-display text-3xl tabular-nums",
							children: servings
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "flex size-12 items-center justify-center rounded-[16px] bg-surface text-2xl font-semibold shadow-[var(--shadow-card)]",
							onClick: () => setServings(servings + 1),
							"aria-label": "Más personas",
							children: "+"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky bottom-3 mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "lg",
					className: "w-full",
					onClick: () => void navigate({ to: "/results" }),
					children: ["Buscar recetas · ", previewCount]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
