import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as cn, s as ingredientName, u as useAppStore } from "./button-CEqpR9ko.mjs";
import { g as Clock, m as Heart } from "../_libs/lucide-react.mjs";
import { t as RecipeIllustration } from "./RecipeIllustration-BcuBo4if.mjs";
import { a as formatMinutes, n as DIFFICULTY_LABEL, t as CATEGORY_LABEL } from "./format-D7jV-Z6e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/RecipeCard-BgsKDekC.js
var import_jsx_runtime = require_jsx_runtime();
function RecipeCard({ scored }) {
	const { recipe, matchCount, total, missing } = scored;
	const favorite = useAppStore((s) => s.favorites.includes(recipe.id));
	const toggleFavorite = useAppStore((s) => s.toggleFavorite);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "relative rounded-[28px] bg-surface p-3 shadow-[var(--shadow-card)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/recipe/$id",
			params: { id: recipe.id },
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "size-[88px] shrink-0 overflow-hidden rounded-[20px]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecipeIllustration, { kind: recipe.illustration })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 pr-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wide text-olive",
						children: CATEGORY_LABEL[recipe.category]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg leading-snug text-ink",
						children: recipe.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-ink-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-3.5" }), formatMinutes(recipe.timeMinutes)]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: DIFFICULTY_LABEL[recipe.difficulty] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm font-semibold text-olive-deep",
						children: [
							"Usas ",
							matchCount,
							" de ",
							total,
							" ingredientes"
						]
					}),
					missing.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 line-clamp-2 text-xs text-terra",
						children: ["Falta: ", missing.map((item) => ingredientName(item.id)).join(", ")]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-semibold text-good",
						children: "La puedes hacer ahora"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: cn("absolute top-3 right-3 flex size-11 items-center justify-center rounded-full", favorite ? "text-terra" : "text-muted"),
			"aria-label": favorite ? "Quitar de favoritos" : "Guardar en favoritos",
			onClick: (event) => {
				event.preventDefault();
				toggleFavorite(recipe.id);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
				className: "size-5",
				fill: favorite ? "currentColor" : "none"
			})
		})]
	});
}
//#endregion
export { RecipeCard as t };
