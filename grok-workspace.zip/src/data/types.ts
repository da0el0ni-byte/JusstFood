export const CATEGORIES = [
  "desayuno",
  "comida",
  "cena",
  "postre",
  "snack",
] as const;

export type Category = (typeof CATEGORIES)[number];

export const DIFFICULTIES = ["facil", "media", "avanzada"] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

export const TAGS = [
  "vegetariano",
  "sin_gluten",
  "alto_proteina",
  "economico",
] as const;
export type Tag = (typeof TAGS)[number];

export const TIME_OPTIONS = [10, 20, 30, 45] as const;
export type MaxTime = (typeof TIME_OPTIONS)[number];

export type IngredientAmount = {
  id: string;
  amount: number;
  unit: "ud" | "g" | "ml" | "cda" | "cdta" | "pizca";
};

export type Recipe = {
  id: string;
  name: string;
  category: Category;
  illustration: string;
  timeMinutes: number;
  servings: number;
  ingredients: IngredientAmount[];
  tags: Tag[];
  steps: string[];
  calories?: number;
  difficulty: Difficulty;
};

export type ScoredRecipe = {
  recipe: Recipe;
  matchCount: number;
  total: number;
  have: IngredientAmount[];
  missing: IngredientAmount[];
  score: number;
};
