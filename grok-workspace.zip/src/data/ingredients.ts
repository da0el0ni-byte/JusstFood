export type Ingredient = {
  id: string;
  name: string;
  group: string;
};

export const INGREDIENT_GROUPS: { id: string; label: string }[] = [
  { id: "basicos", label: "Básicos" },
  { id: "proteinas", label: "Proteínas" },
  { id: "verduras", label: "Verduras" },
  { id: "despensa", label: "Despensa" },
  { id: "lacteos", label: "Lácteos" },
  { id: "frutas", label: "Frutas y frutos" },
];

export const INGREDIENTS: Ingredient[] = [
  { id: "aceite_oliva", name: "Aceite de oliva", group: "basicos" },
  { id: "sal", name: "Sal", group: "basicos" },
  { id: "pimienta", name: "Pimienta", group: "basicos" },
  { id: "ajo", name: "Ajo", group: "basicos" },
  { id: "cebolla", name: "Cebolla", group: "basicos" },
  { id: "limon", name: "Limón", group: "basicos" },
  { id: "vinagre", name: "Vinagre", group: "basicos" },
  { id: "agua", name: "Agua", group: "basicos" },

  { id: "huevo", name: "Huevo", group: "proteinas" },
  { id: "pollo", name: "Pollo", group: "proteinas" },
  { id: "atun", name: "Atún", group: "proteinas" },
  { id: "salmon", name: "Salmón", group: "proteinas" },
  { id: "tofu", name: "Tofu", group: "proteinas" },
  { id: "jamon", name: "Jamón", group: "proteinas" },
  { id: "carne_picada", name: "Carne picada", group: "proteinas" },
  { id: "garbanzos", name: "Garbanzos", group: "proteinas" },
  { id: "lentejas", name: "Lentejas", group: "proteinas" },

  { id: "tomate", name: "Tomate", group: "verduras" },
  { id: "pimiento", name: "Pimiento", group: "verduras" },
  { id: "zanahoria", name: "Zanahoria", group: "verduras" },
  { id: "patata", name: "Patata", group: "verduras" },
  { id: "lechuga", name: "Lechuga", group: "verduras" },
  { id: "espinaca", name: "Espinaca", group: "verduras" },
  { id: "calabacin", name: "Calabacín", group: "verduras" },
  { id: "champinon", name: "Champiñón", group: "verduras" },
  { id: "pepino", name: "Pepino", group: "verduras" },
  { id: "brocoli", name: "Brócoli", group: "verduras" },
  { id: "aguacate", name: "Aguacate", group: "verduras" },

  { id: "arroz", name: "Arroz", group: "despensa" },
  { id: "pasta", name: "Pasta", group: "despensa" },
  { id: "pan", name: "Pan", group: "despensa" },
  { id: "harina", name: "Harina", group: "despensa" },
  { id: "avena", name: "Avena", group: "despensa" },
  { id: "azucar", name: "Azúcar", group: "despensa" },
  { id: "miel", name: "Miel", group: "despensa" },
  { id: "cacao", name: "Cacao", group: "despensa" },
  { id: "cafe", name: "Café", group: "despensa" },
  { id: "canela", name: "Canela", group: "despensa" },
  { id: "comino", name: "Comino", group: "despensa" },
  { id: "pimenton", name: "Pimentón", group: "despensa" },
  { id: "chocolate", name: "Chocolate", group: "despensa" },

  { id: "yogur", name: "Yogur", group: "lacteos" },
  { id: "queso", name: "Queso", group: "lacteos" },
  { id: "leche", name: "Leche", group: "lacteos" },
  { id: "mantequilla", name: "Mantequilla", group: "lacteos" },
  { id: "nata", name: "Nata", group: "lacteos" },

  { id: "platano", name: "Plátano", group: "frutas" },
  { id: "manzana", name: "Manzana", group: "frutas" },
  { id: "fresa", name: "Fresa", group: "frutas" },
  { id: "naranja", name: "Naranja", group: "frutas" },
  { id: "nueces", name: "Nueces", group: "frutas" },
  { id: "almendras", name: "Almendras", group: "frutas" },
];

export const INGREDIENT_MAP = new Map(INGREDIENTS.map((item) => [item.id, item]));

export function ingredientName(id: string): string {
  return INGREDIENT_MAP.get(id)?.name ?? id;
}

/** Pantry items that never block “puedo hacer ahora”. */
export const STAPLE_IDS = new Set(["sal", "pimienta", "aceite_oliva", "agua"]);

export const DEFAULT_SELECTED = ["aceite_oliva", "sal", "pimienta"];
