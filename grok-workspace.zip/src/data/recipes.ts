import type { Recipe } from "./types";
import data from "./recipes.json";

export const recipes = data as Recipe[];
