import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { DEFAULT_SELECTED } from "@/data/ingredients";
import {
  ADS_DISABLED_BY_DEFAULT,
  INTERSTITIAL_AFTER_RECIPES,
  INTERSTITIAL_COOLDOWN_MS,
} from "@/lib/ads";
import type { Category, MaxTime, Tag } from "@/data/types";

export type TimerState = {
  running: boolean;
  remaining: number;
  duration: number;
  recipeId: string | null;
};

type AppState = {
  hydrated: boolean;
  setHydrated: (value: boolean) => void;

  ingredientIds: string[];
  toggleIngredient: (id: string) => void;
  setIngredients: (ids: string[]) => void;
  clearIngredients: () => void;

  maxTime: MaxTime;
  setMaxTime: (time: MaxTime) => void;
  category: Category | null;
  setCategory: (category: Category | null) => void;
  tags: Tag[];
  toggleTag: (tag: Tag) => void;
  servings: number;
  setServings: (n: number) => void;
  onlyNow: boolean;
  setOnlyNow: (value: boolean) => void;

  favorites: string[];
  toggleFavorite: (id: string) => void;
  clearFavorites: () => void;
  isFavorite: (id: string) => boolean;

  adsDisabled: boolean;
  setAdsDisabled: (value: boolean) => void;
  openedRecipeIds: string[];
  lastInterstitialAt: number;
  interstitialVisible: boolean;
  rewardedVisible: boolean;
  markRecipeOpened: (id: string) => void;
  shouldOfferInterstitial: () => boolean;
  showInterstitial: () => void;
  hideInterstitial: () => void;
  showRewarded: () => void;
  hideRewarded: () => void;

  timer: TimerState;
  startTimer: (seconds: number, recipeId: string) => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  tickTimer: () => void;
  resetTimer: () => void;
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      setHydrated: (value) => set({ hydrated: value }),

      ingredientIds: DEFAULT_SELECTED,
      toggleIngredient: (id) =>
        set((state) => ({
          ingredientIds: state.ingredientIds.includes(id)
            ? state.ingredientIds.filter((item) => item !== id)
            : [...state.ingredientIds, id],
        })),
      setIngredients: (ids) => set({ ingredientIds: ids }),
      clearIngredients: () => set({ ingredientIds: [] }),

      maxTime: 30,
      setMaxTime: (time) => set({ maxTime: time }),
      category: null,
      setCategory: (category) => set({ category }),
      tags: [],
      toggleTag: (tag) =>
        set((state) => ({
          tags: state.tags.includes(tag)
            ? state.tags.filter((item) => item !== tag)
            : [...state.tags, tag],
        })),
      servings: 2,
      setServings: (n) => set({ servings: Math.min(8, Math.max(1, n)) }),
      onlyNow: false,
      setOnlyNow: (value) => set({ onlyNow: value }),

      favorites: [],
      toggleFavorite: (id) =>
        set((state) => ({
          favorites: state.favorites.includes(id)
            ? state.favorites.filter((item) => item !== id)
            : [...state.favorites, id],
        })),
      clearFavorites: () => set({ favorites: [] }),
      isFavorite: (id) => get().favorites.includes(id),

      adsDisabled: ADS_DISABLED_BY_DEFAULT,
      setAdsDisabled: (value) => set({ adsDisabled: value }),
      openedRecipeIds: [],
      lastInterstitialAt: 0,
      interstitialVisible: false,
      rewardedVisible: false,
      markRecipeOpened: (id) =>
        set((state) => ({
          openedRecipeIds: state.openedRecipeIds.includes(id)
            ? state.openedRecipeIds
            : [...state.openedRecipeIds, id],
        })),
      shouldOfferInterstitial: () => {
        const state = get();
        if (ADS_DISABLED_BY_DEFAULT || state.adsDisabled) return false;
        if (state.timer.running) return false;
        if (state.openedRecipeIds.length < INTERSTITIAL_AFTER_RECIPES) return false;
        if (Date.now() - state.lastInterstitialAt < INTERSTITIAL_COOLDOWN_MS) {
          return false;
        }
        return true;
      },
      showInterstitial: () =>
        set({ interstitialVisible: true, lastInterstitialAt: Date.now() }),
      hideInterstitial: () => set({ interstitialVisible: false }),
      showRewarded: () => set({ rewardedVisible: true }),
      hideRewarded: () => set({ rewardedVisible: false }),

      timer: { running: false, remaining: 0, duration: 0, recipeId: null },
      startTimer: (seconds, recipeId) =>
        set({
          timer: {
            running: true,
            remaining: seconds,
            duration: seconds,
            recipeId,
          },
        }),
      pauseTimer: () =>
        set((state) => ({ timer: { ...state.timer, running: false } })),
      resumeTimer: () =>
        set((state) => ({
          timer: {
            ...state.timer,
            running: state.timer.remaining > 0,
          },
        })),
      tickTimer: () =>
        set((state) => {
          if (!state.timer.running) return state;
          const remaining = Math.max(0, state.timer.remaining - 1);
          return {
            timer: {
              ...state.timer,
              remaining,
              running: remaining > 0,
            },
          };
        }),
      resetTimer: () =>
        set({
          timer: { running: false, remaining: 0, duration: 0, recipeId: null },
        }),
    }),
    {
      name: "que-como-hoy",
      skipHydration: true,
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        ingredientIds: state.ingredientIds,
        maxTime: state.maxTime,
        category: state.category,
        tags: state.tags,
        servings: state.servings,
        onlyNow: state.onlyNow,
        favorites: state.favorites,
        adsDisabled: state.adsDisabled,
        openedRecipeIds: state.openedRecipeIds,
        lastInterstitialAt: state.lastInterstitialAt,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    },
  ),
);
