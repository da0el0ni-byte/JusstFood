import type { Category, Difficulty, Tag } from "@/data/types";

export const CATEGORY_LABEL: Record<Category, string> = {
  desayuno: "Desayuno",
  comida: "Comida",
  cena: "Cena",
  postre: "Postre",
  snack: "Snack",
};

export const DIFFICULTY_LABEL: Record<Difficulty, string> = {
  facil: "Fácil",
  media: "Media",
  avanzada: "Avanzada",
};

export const TAG_LABEL: Record<Tag, string> = {
  vegetariano: "Vegetariano",
  sin_gluten: "Sin gluten",
  alto_proteina: "Alto en proteína",
  economico: "Económico",
};

export function formatAmount(amount: number, unit: string): string {
  const rounded =
    unit === "ud" || unit === "cda" || unit === "cdta"
      ? Math.round(amount * 2) / 2
      : Math.round(amount);
  const n =
    Number.isInteger(rounded) ? String(rounded) : String(rounded).replace(".", ",");

  switch (unit) {
    case "ud":
      return rounded === 1 ? "1 unidad" : `${n} unidades`;
    case "cda":
      return rounded === 1 ? "1 cucharada" : `${n} cucharadas`;
    case "cdta":
      return rounded === 1 ? "1 cucharadita" : `${n} cucharaditas`;
    case "g":
      return `${n} g`;
    case "ml":
      return `${n} ml`;
    case "pizca":
      return "1 pizca";
    default:
      return `${n} ${unit}`;
  }
}

export function scaleAmount(
  amount: number,
  recipeServings: number,
  people: number,
): number {
  if (recipeServings <= 0) return amount;
  return (amount * people) / recipeServings;
}

export function formatMinutes(minutes: number): string {
  return `${minutes} min`;
}
