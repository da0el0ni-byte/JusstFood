import { STAPLE_IDS } from "@/data/ingredients";
import { recipes } from "@/data/recipes";
import type { Category, MaxTime, Recipe, ScoredRecipe, Tag } from "@/data/types";

export type SearchInput = {
  ingredientIds: string[];
  maxTime: MaxTime;
  category: Category | null;
  tags: Tag[];
  onlyNow: boolean;
};

export function scoreRecipe(recipe: Recipe, selected: Set<string>): ScoredRecipe {
  const have = recipe.ingredients.filter((item) => selected.has(item.id));
  const missing = recipe.ingredients.filter(
    (item) => !selected.has(item.id) && !STAPLE_IDS.has(item.id),
  );
  const total = recipe.ingredients.filter((item) => !STAPLE_IDS.has(item.id)).length;
  const matchCount = recipe.ingredients.filter(
    (item) => selected.has(item.id) && !STAPLE_IDS.has(item.id),
  ).length;
  const score = total === 0 ? 0 : matchCount / total;
  return { recipe, matchCount, total, have, missing, score };
}

export function searchRecipes(input: SearchInput): ScoredRecipe[] {
  const selected = new Set(input.ingredientIds);

  const scored = recipes
    .filter((recipe) => {
      if (recipe.timeMinutes > input.maxTime) return false;
      if (input.category && recipe.category !== input.category) return false;
      if (input.tags.some((tag) => !recipe.tags.includes(tag))) return false;
      return true;
    })
    .map((recipe) => scoreRecipe(recipe, selected))
    .filter((item) => (input.onlyNow ? item.missing.length === 0 : true));

  scored.sort((a, b) => {
    if (b.matchCount !== a.matchCount) return b.matchCount - a.matchCount;
    if (b.score !== a.score) return b.score - a.score;
    return a.recipe.timeMinutes - b.recipe.timeMinutes;
  });

  return scored;
}

export function getRecipeById(id: string): Recipe | undefined {
  return recipes.find((recipe) => recipe.id === id);
}

export function pickSurpriseRecipe(excludeIds: string[] = []): Recipe | undefined {
  const pool = recipes.filter((recipe) => !excludeIds.includes(recipe.id));
  const source = pool.length > 0 ? pool : recipes;
  if (source.length === 0) return undefined;
  const index = Math.floor(Math.random() * source.length);
  return source[index];
}
