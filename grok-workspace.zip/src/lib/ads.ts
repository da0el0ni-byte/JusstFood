/**
 * Google AdMob — configuración de anuncios.
 *
 * Durante el desarrollo se usan IDs de PRUEBA oficiales de Google.
 * SUSTITUIR ANTES DE PUBLICAR: reemplaza estos IDs de prueba por tus IDs
 * reales de AdMob (aplicación Android + unidades de anuncio).
 *
 * IDs de prueba oficiales:
 *   App:          ca-app-pub-3940256099942544~3347511713
 *   Banner:       ca-app-pub-3940256099942544/6300978111
 *   Interstitial: ca-app-pub-3940256099942544/1033173712
 *   Rewarded:     ca-app-pub-3940256099942544/5224354917
 */

/** Cambia a `true` para desactivar todos los anuncios durante el desarrollo. */
export const ADS_DISABLED_BY_DEFAULT = false;

export const INTERSTITIAL_AFTER_RECIPES = 5;
export const INTERSTITIAL_COOLDOWN_MS = 10 * 60 * 1000;
export const BANNER_RESERVED_PX = 64;

export const ADMOB = {
  // SUSTITUIR ANTES DE PUBLICAR: ID de aplicación AdMob real.
  appId: "ca-app-pub-3940256099942544~3347511713",
  // SUSTITUIR ANTES DE PUBLICAR: ID de banner adaptativo real.
  bannerId: "ca-app-pub-3940256099942544/6300978111",
  // SUSTITUIR ANTES DE PUBLICAR: ID de intersticial real.
  interstitialId: "ca-app-pub-3940256099942544/1033173712",
  // SUSTITUIR ANTES DE PUBLICAR: ID de anuncio recompensado real.
  rewardedId: "ca-app-pub-3940256099942544/5224354917",
} as const;

export function isTestAdId(id: string): boolean {
  return id.includes("3940256099942544");
}
