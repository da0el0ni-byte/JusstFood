import { createFileRoute } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { RecipeCard } from "@/components/RecipeCard";
import { recipes } from "@/data/recipes";
import { scoreRecipe } from "@/lib/search";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/favorites")({ component: FavoritesPage });

function FavoritesPage() {
  const favorites = useAppStore((s) => s.favorites);
  const hydrated = useAppStore((s) => s.hydrated);
  const ingredientIds = useAppStore((s) => s.ingredientIds);
  const selected = new Set(ingredientIds);

  const items = recipes
    .filter((recipe) => favorites.includes(recipe.id))
    .map((recipe) => scoreRecipe(recipe, selected));

  return (
    <main className="flex flex-1 flex-col px-5 pt-8 pb-6">
      <h1 className="font-display text-3xl text-ink">Favoritos</h1>
      <p className="mt-1 text-sm text-muted">Se guardan en este dispositivo.</p>

      {!hydrated ? (
        <p className="mt-8 text-sm text-muted">Cargando…</p>
      ) : items.length === 0 ? (
        <div className="mt-8 rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]">
          <Heart className="mx-auto size-8 text-terra" />
          <p className="mt-3 font-display text-xl">Aún no hay favoritos</p>
          <p className="mt-2 text-sm text-ink-soft">
            Abre una receta y pulsa el corazón para guardarla.
          </p>
        </div>
      ) : (
        <div className="mt-5 flex flex-col gap-3">
          {items.map((scored) => (
            <RecipeCard key={scored.recipe.id} scored={scored} />
          ))}
        </div>
      )}
    </main>
  );
}
