import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, Gift } from "lucide-react";
import { AdBanner } from "@/components/ads/AdBanner";
import { RecipeCard } from "@/components/RecipeCard";
import { ADS_DISABLED_BY_DEFAULT } from "@/lib/ads";
import { searchRecipes } from "@/lib/search";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/results")({ component: ResultsPage });

function ResultsPage() {
  const navigate = useNavigate();
  const ingredientIds = useAppStore((s) => s.ingredientIds);
  const maxTime = useAppStore((s) => s.maxTime);
  const category = useAppStore((s) => s.category);
  const tags = useAppStore((s) => s.tags);
  const onlyNow = useAppStore((s) => s.onlyNow);
  const setOnlyNow = useAppStore((s) => s.setOnlyNow);
  const adsDisabled = useAppStore((s) => s.adsDisabled);
  const showRewarded = useAppStore((s) => s.showRewarded);

  const results = searchRecipes({
    ingredientIds,
    maxTime,
    category,
    tags,
    onlyNow,
  });

  return (
    <main className="flex flex-1 flex-col">
      <header className="sticky top-0 z-20 flex items-center gap-2 bg-bg/95 px-3 py-3 backdrop-blur-sm">
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full"
          onClick={() => void navigate({ to: "/" })}
          aria-label="Volver"
        >
          <ChevronLeft className="size-6" />
        </button>
        <div>
          <h1 className="font-display text-2xl leading-none text-ink">Recetas</h1>
          <p className="text-sm text-muted">{results.length} coincidencias</p>
        </div>
      </header>

      <div className="px-5">
        <button
          type="button"
          onClick={() => setOnlyNow(!onlyNow)}
          className={cn(
            "flex h-12 w-full items-center justify-between rounded-[20px] px-4 text-sm font-semibold",
            onlyNow ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]",
          )}
        >
          Solo recetas que puedo hacer ahora
          <span className={cn("text-xs font-bold", onlyNow ? "text-surface" : "text-olive")}>
            {onlyNow ? "Sí" : "No"}
          </span>
        </button>
      </div>

      <div className="mt-4 flex flex-1 flex-col gap-3 px-5 pb-4">
        {results.length === 0 ? (
          <div className="rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]">
            <p className="font-display text-xl text-ink">Ninguna receta encaja</p>
            <p className="mt-2 text-sm text-ink-soft">
              Prueba a añadir más ingredientes o desactiva el filtro de “solo ahora”.
            </p>
          </div>
        ) : (
          results.map((scored) => <RecipeCard key={scored.recipe.id} scored={scored} />)
        )}

        {!ADS_DISABLED_BY_DEFAULT && !adsDisabled ? (
          <button
            type="button"
            onClick={showRewarded}
            className="mt-2 flex items-start gap-3 rounded-[28px] bg-olive-soft p-4 text-left"
          >
            <Gift className="mt-0.5 size-5 shrink-0 text-olive-deep" />
            <span>
              <span className="block font-display text-lg text-olive-deep">Receta sorpresa</span>
              <span className="mt-1 block text-sm text-ink-soft">
                Opcional: mira un anuncio de prueba y te mostramos una receta al azar.
              </span>
            </span>
          </button>
        ) : null}
      </div>
      <AdBanner />
    </main>
  );
}
