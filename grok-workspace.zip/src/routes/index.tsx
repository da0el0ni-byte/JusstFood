import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Leaf, Shield, UserRound, Wallet } from "lucide-react";
import { IngredientPicker } from "@/components/IngredientPicker";
import { Button } from "@/components/ui/button";
import { CATEGORIES, TIME_OPTIONS, type Tag } from "@/data/types";
import { CATEGORY_LABEL, TAG_LABEL } from "@/lib/format";
import { searchRecipes } from "@/lib/search";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const TAG_META: { id: Tag; icon: typeof Leaf }[] = [
  { id: "vegetariano", icon: Leaf },
  { id: "sin_gluten", icon: Shield },
  { id: "alto_proteina", icon: UserRound },
  { id: "economico", icon: Wallet },
];

function Home() {
  const navigate = useNavigate();
  const ingredientIds = useAppStore((s) => s.ingredientIds);
  const maxTime = useAppStore((s) => s.maxTime);
  const setMaxTime = useAppStore((s) => s.setMaxTime);
  const category = useAppStore((s) => s.category);
  const setCategory = useAppStore((s) => s.setCategory);
  const tags = useAppStore((s) => s.tags);
  const toggleTag = useAppStore((s) => s.toggleTag);
  const servings = useAppStore((s) => s.servings);
  const setServings = useAppStore((s) => s.setServings);

  const previewCount = searchRecipes({
    ingredientIds,
    maxTime,
    category,
    tags,
    onlyNow: false,
  }).length;

  return (
    <main className="flex flex-1 flex-col px-5 pt-8 pb-6">
      <header className="stagger-in">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-olive">
          Cocina de casa
        </p>
        <h1 className="mt-1 font-display text-[2.15rem] leading-[1.1] tracking-tight text-ink">
          ¿Qué como hoy?
        </h1>
        <p className="mt-2 max-w-[22ch] text-base leading-relaxed text-ink-soft">
          Elige lo que tienes y te decimos qué puedes cocinar.
        </p>
      </header>

      <div className="mt-7">
        <IngredientPicker />
      </div>

      <section className="mt-8">
        <h2 className="font-display text-xl text-ink">Tiempo máximo</h2>
        <div className="mt-3 grid grid-cols-4 gap-2">
          {TIME_OPTIONS.map((time) => (
            <button
              key={time}
              type="button"
              onClick={() => setMaxTime(time)}
              className={cn(
                "h-12 rounded-[16px] text-sm font-bold transition-colors duration-150",
                maxTime === time
                  ? "bg-olive text-surface"
                  : "bg-surface text-ink shadow-[var(--shadow-card)]",
              )}
            >
              {time}’
            </button>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="font-display text-xl text-ink">Tipo de comida</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setCategory(null)}
            className={cn(
              "h-11 rounded-full px-4 text-sm font-semibold",
              category === null
                ? "bg-olive text-surface"
                : "bg-surface text-ink shadow-[var(--shadow-card)]",
            )}
          >
            Todas
          </button>
          {CATEGORIES.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => setCategory(item)}
              className={cn(
                "h-11 rounded-full px-4 text-sm font-semibold",
                category === item
                  ? "bg-olive text-surface"
                  : "bg-surface text-ink shadow-[var(--shadow-card)]",
              )}
            >
              {CATEGORY_LABEL[item]}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="font-display text-xl text-ink">Preferencias</h2>
        <p className="mt-1 text-sm text-muted">Opcional</p>
        <div className="mt-3 grid grid-cols-2 gap-2">
          {TAG_META.map(({ id, icon: Icon }) => {
            const on = tags.includes(id);
            return (
              <button
                key={id}
                type="button"
                onClick={() => toggleTag(id)}
                className={cn(
                  "flex h-14 items-center gap-2 rounded-[20px] px-3 text-left text-sm font-semibold",
                  on ? "bg-olive text-surface" : "bg-surface text-ink shadow-[var(--shadow-card)]",
                )}
              >
                <Icon className="size-4 shrink-0" />
                {TAG_LABEL[id]}
              </button>
            );
          })}
        </div>
      </section>

      <section className="mt-8">
        <h2 className="font-display text-xl text-ink">Personas</h2>
        <div className="mt-3 flex items-center gap-3">
          <button
            type="button"
            className="flex size-12 items-center justify-center rounded-[16px] bg-surface text-2xl font-semibold shadow-[var(--shadow-card)]"
            onClick={() => setServings(servings - 1)}
            aria-label="Menos personas"
          >
            −
          </button>
          <p className="min-w-10 text-center font-display text-3xl tabular-nums">{servings}</p>
          <button
            type="button"
            className="flex size-12 items-center justify-center rounded-[16px] bg-surface text-2xl font-semibold shadow-[var(--shadow-card)]"
            onClick={() => setServings(servings + 1)}
            aria-label="Más personas"
          >
            +
          </button>
        </div>
      </section>

      <div className="sticky bottom-3 mt-8">
        <Button
          size="lg"
          className="w-full"
          onClick={() => void navigate({ to: "/results" })}
        >
          Buscar recetas · {previewCount}
        </Button>
      </div>
    </main>
  );
}
