import { useEffect } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, Clock, Heart, Users } from "lucide-react";
import { RecipeIllustration } from "@/components/RecipeIllustration";
import { RecipeTimer } from "@/components/Timer";
import { ingredientName, STAPLE_IDS } from "@/data/ingredients";
import { CATEGORY_LABEL, DIFFICULTY_LABEL, formatAmount, scaleAmount, TAG_LABEL } from "@/lib/format";
import { getRecipeById, scoreRecipe } from "@/lib/search";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/recipe/$id")({
  component: RecipeDetailPage,
});

function RecipeDetailPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const recipe = getRecipeById(id);
  const ingredientIds = useAppStore((s) => s.ingredientIds);
  const servings = useAppStore((s) => s.servings);
  const favorite = useAppStore((s) => s.favorites.includes(id));
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);
  const markRecipeOpened = useAppStore((s) => s.markRecipeOpened);
  const shouldOfferInterstitial = useAppStore((s) => s.shouldOfferInterstitial);
  const showInterstitial = useAppStore((s) => s.showInterstitial);
  const timerRunning = useAppStore((s) => s.timer.running);

  useEffect(() => {
    if (recipe) markRecipeOpened(recipe.id);
  }, [recipe, markRecipeOpened]);

  if (!recipe) {
    return (
      <main className="px-5 py-10 text-center">
        <p className="font-display text-2xl">Receta no encontrada</p>
        <button className="mt-4 font-semibold text-olive" onClick={() => void navigate({ to: "/" })}>
          Volver al inicio
        </button>
      </main>
    );
  }

  const scored = scoreRecipe(recipe, new Set(ingredientIds));
  const missingIds = new Set(scored.missing.map((item) => item.id));

  function goBack() {
    if (!timerRunning && shouldOfferInterstitial()) {
      showInterstitial();
    }
    void navigate({ to: "/results" });
  }

  return (
    <main className="flex flex-1 flex-col pb-8">
      <header className="sticky top-0 z-20 flex items-center justify-between bg-bg/95 px-3 py-3 backdrop-blur-sm">
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-full"
          onClick={goBack}
          aria-label="Volver"
        >
          <ChevronLeft className="size-6" />
        </button>
        <p className="text-sm font-semibold text-olive">{CATEGORY_LABEL[recipe.category]}</p>
        <button
          type="button"
          className={cn(
            "flex size-11 items-center justify-center rounded-full",
            favorite ? "text-terra" : "text-muted",
          )}
          aria-label={favorite ? "Quitar de favoritos" : "Guardar en favoritos"}
          onClick={() => toggleFavorite(recipe.id)}
        >
          <Heart className="size-5" fill={favorite ? "currentColor" : "none"} />
        </button>
      </header>

      <div className="px-5">
        <div className="mx-auto size-36 overflow-hidden rounded-[32px]">
          <RecipeIllustration kind={recipe.illustration} />
        </div>
        <h1 className="mt-4 text-center font-display text-3xl leading-tight text-ink">
          {recipe.name}
        </h1>
        <div className="mt-3 flex flex-wrap justify-center gap-2 text-sm text-ink-soft">
          <span className="inline-flex h-9 items-center gap-1 rounded-full bg-surface px-3 shadow-[var(--shadow-card)]">
            <Clock className="size-3.5" /> {recipe.timeMinutes} min
          </span>
          <span className="inline-flex h-9 items-center gap-1 rounded-full bg-surface px-3 shadow-[var(--shadow-card)]">
            <Users className="size-3.5" /> {servings} {servings === 1 ? "persona" : "personas"}
          </span>
          <span className="inline-flex h-9 items-center rounded-full bg-surface px-3 shadow-[var(--shadow-card)]">
            {DIFFICULTY_LABEL[recipe.difficulty]}
          </span>
          {recipe.calories ? (
            <span className="inline-flex h-9 items-center rounded-full bg-surface px-3 shadow-[var(--shadow-card)]">
              {recipe.calories} kcal aprox.
            </span>
          ) : null}
        </div>
        <div className="mt-3 flex flex-wrap justify-center gap-2">
          {recipe.tags.map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-olive-soft px-3 py-1 text-xs font-semibold text-olive-deep"
            >
              {TAG_LABEL[tag]}
            </span>
          ))}
        </div>
      </div>

      <section className="mt-8 px-5">
        <h2 className="font-display text-xl text-ink">Ingredientes</h2>
        <ul className="mt-3 space-y-2">
          {recipe.ingredients.map((item) => {
            const missing = missingIds.has(item.id);
            const staple = STAPLE_IDS.has(item.id);
            const amount = scaleAmount(item.amount, recipe.servings, servings);
            return (
              <li
                key={item.id}
                className={cn(
                  "flex items-center justify-between rounded-[16px] px-3 py-3",
                  missing ? "bg-terra-soft" : "bg-surface shadow-[var(--shadow-card)]",
                )}
              >
                <span className="font-semibold text-ink">
                  {ingredientName(item.id)}
                  {missing ? (
                    <span className="ml-2 text-xs font-bold text-terra">Falta</span>
                  ) : staple ? null : (
                    <span className="ml-2 text-xs font-bold text-good">Lo tienes</span>
                  )}
                </span>
                <span className="text-sm text-ink-soft">{formatAmount(amount, item.unit)}</span>
              </li>
            );
          })}
        </ul>
      </section>

      <section className="mt-8 px-5">
        <h2 className="font-display text-xl text-ink">Pasos</h2>
        <ol className="mt-3 space-y-3">
          {recipe.steps.map((step, index) => (
            <li key={step} className="flex gap-3 rounded-[20px] bg-surface p-3 shadow-[var(--shadow-card)]">
              <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-olive font-display text-sm text-surface">
                {index + 1}
              </span>
              <p className="pt-1 text-base leading-relaxed text-ink">{step}</p>
            </li>
          ))}
        </ol>
      </section>

      <div className="mt-8 px-5">
        <RecipeTimer recipeId={recipe.id} defaultMinutes={recipe.timeMinutes} />
      </div>
    </main>
  );
}
