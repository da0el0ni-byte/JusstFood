import { createFileRoute } from "@tanstack/react-router";
import { ADS_DISABLED_BY_DEFAULT, ADMOB } from "@/lib/ads";
import { recipes } from "@/data/recipes";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

function SettingsPage() {
  const favorites = useAppStore((s) => s.favorites);
  const clearFavorites = useAppStore((s) => s.clearFavorites);
  const adsDisabled = useAppStore((s) => s.adsDisabled);
  const setAdsDisabled = useAppStore((s) => s.setAdsDisabled);

  return (
    <main className="flex flex-1 flex-col px-5 pt-8 pb-8">
      <h1 className="font-display text-3xl text-ink">Ajustes</h1>

      <section className="mt-6 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]">
        <h2 className="font-display text-xl">Datos en el dispositivo</h2>
        <p className="mt-1 text-sm text-ink-soft">
          Tienes {favorites.length} recetas favoritas guardadas.
        </p>
        <Button
          className="mt-4 w-full"
          variant="terra"
          onClick={clearFavorites}
          disabled={favorites.length === 0}
        >
          Borrar favoritos
        </Button>
      </section>

      <section className="mt-4 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]">
        <h2 className="font-display text-xl">Anuncios</h2>
        <p className="mt-1 text-sm leading-relaxed text-ink-soft">
          Ahora mismo se usan IDs de prueba de Google AdMob. Antes de publicar, sustituye los IDs en
          el archivo de configuración de anuncios.
        </p>
        <button
          type="button"
          onClick={() => setAdsDisabled(!adsDisabled)}
          className={cn(
            "mt-4 flex h-12 w-full items-center justify-between rounded-[16px] px-4 text-sm font-semibold",
            adsDisabled || ADS_DISABLED_BY_DEFAULT
              ? "bg-olive text-surface"
              : "bg-olive-soft text-olive-deep",
          )}
        >
          Desactivar anuncios (desarrollo)
          <span>{adsDisabled || ADS_DISABLED_BY_DEFAULT ? "Sí" : "No"}</span>
        </button>
        <dl className="mt-4 space-y-1 font-mono text-[10px] leading-relaxed text-muted">
          <div>Banner {ADMOB.bannerId}</div>
          <div>Intersticial {ADMOB.interstitialId}</div>
          <div>Recompensado {ADMOB.rewardedId}</div>
        </dl>
      </section>

      <section className="mt-4 rounded-[28px] bg-surface p-5 shadow-[var(--shadow-card)]">
        <h2 className="font-display text-xl">Acerca de</h2>
        <p className="mt-2 text-sm leading-relaxed text-ink-soft">
          ¿Qué como hoy? te ayuda a decidir qué cocinar con lo que ya tienes. {recipes.length} recetas
          originales, sin cuenta y sin conexión.
        </p>
        <p className="mt-3 text-sm text-muted">Versión 1.0</p>
      </section>
    </main>
  );
}
