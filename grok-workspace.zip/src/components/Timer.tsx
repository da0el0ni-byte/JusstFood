import { useEffect } from "react";
import { Pause, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

function beep() {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.value = 0.08;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.35);
  } catch {
    /* audio optional */
  }
}

export function TimerTicker() {
  const running = useAppStore((s) => s.timer.running);
  const remaining = useAppStore((s) => s.timer.remaining);
  const duration = useAppStore((s) => s.timer.duration);
  const tickTimer = useAppStore((s) => s.tickTimer);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => tickTimer(), 1000);
    return () => window.clearInterval(id);
  }, [running, tickTimer]);

  useEffect(() => {
    if (remaining === 0 && duration > 0 && !running) beep();
  }, [remaining, duration, running]);

  return null;
}

function formatClock(total: number): string {
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function RecipeTimer({
  recipeId,
  defaultMinutes,
}: {
  recipeId: string;
  defaultMinutes: number;
}) {
  const timer = useAppStore((s) => s.timer);
  const startTimer = useAppStore((s) => s.startTimer);
  const pauseTimer = useAppStore((s) => s.pauseTimer);
  const resumeTimer = useAppStore((s) => s.resumeTimer);
  const resetTimer = useAppStore((s) => s.resetTimer);

  const active = timer.recipeId === recipeId && timer.duration > 0;
  const display = active ? timer.remaining : defaultMinutes * 60;
  const progress = active && timer.duration > 0 ? timer.remaining / timer.duration : 1;

  return (
    <section className="rounded-[28px] bg-surface p-4 shadow-[var(--shadow-card)]">
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">
            Temporizador
          </p>
          <p className="font-display text-3xl tabular-nums leading-tight text-ink">
            {formatClock(display)}
          </p>
        </div>
        <div
          className="relative size-16"
          aria-hidden="true"
        >
          <svg viewBox="0 0 36 36" className="-rotate-90">
            <circle cx="18" cy="18" r="15" fill="none" stroke="#E7EDD4" strokeWidth="4" />
            <circle
              cx="18"
              cy="18"
              r="15"
              fill="none"
              stroke="#5F6E32"
              strokeWidth="4"
              strokeDasharray={`${progress * 94.2} 94.2`}
              strokeLinecap="round"
            />
          </svg>
        </div>
      </div>
      <div className="mt-3 flex gap-2">
        <Button
          className="flex-1"
          onClick={() => {
            if (!active) startTimer(defaultMinutes * 60, recipeId);
            else if (timer.running) pauseTimer();
            else resumeTimer();
          }}
        >
          {active && timer.running ? (
            <>
              <Pause className="size-4" /> Pausar
            </>
          ) : (
            <>
              <Play className="size-4" /> {active ? "Seguir" : "Iniciar"}
            </>
          )}
        </Button>
        <Button variant="outline" size="icon" onClick={resetTimer} aria-label="Reiniciar">
          <RotateCcw className="size-4" />
        </Button>
      </div>
      {timer.remaining === 0 && active ? (
        <p className="mt-3 rounded-[16px] bg-olive-soft px-3 py-2 text-sm font-semibold text-olive-deep">
          Tiempo terminado
        </p>
      ) : null}
    </section>
  );
}

export function MiniTimerChip({ className }: { className?: string }) {
  const timer = useAppStore((s) => s.timer);
  if (!timer.running && timer.remaining <= 0) return null;
  return (
    <div
      className={cn(
        "rounded-full bg-olive px-3 py-1.5 text-sm font-semibold tabular-nums text-surface",
        className,
      )}
    >
      {formatClock(timer.remaining)}
    </div>
  );
}
