import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

type Props = {
  kind: string;
  className?: string;
};

function Frame({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <svg
      viewBox="0 0 120 120"
      className={cn("h-full w-full", className)}
      aria-hidden="true"
    >
      <rect width="120" height="120" rx="28" fill="#E7EDD4" />
      {children}
    </svg>
  );
}

export function RecipeIllustration({ kind, className }: Props) {
  switch (kind) {
    case "eggs":
      return (
        <Frame className={className}>
          <ellipse cx="48" cy="62" rx="22" ry="28" fill="#FFFBF4" />
          <ellipse cx="76" cy="58" rx="20" ry="26" fill="#F6E4D8" />
          <circle cx="76" cy="58" r="10" fill="#C2663A" />
        </Frame>
      );
    case "oats":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="78" rx="36" ry="14" fill="#C2663A" />
          <ellipse cx="60" cy="70" rx="32" ry="22" fill="#FFFBF4" />
          <circle cx="46" cy="66" r="6" fill="#5F6E32" />
          <circle cx="62" cy="60" r="5" fill="#C2663A" />
          <circle cx="74" cy="68" r="6" fill="#5F6E32" />
        </Frame>
      );
    case "toast":
      return (
        <Frame className={className}>
          <rect x="28" y="30" width="64" height="60" rx="14" fill="#C2663A" />
          <rect x="34" y="36" width="52" height="48" rx="10" fill="#F6E4D8" />
          <circle cx="60" cy="60" r="12" fill="#5F6E32" />
        </Frame>
      );
    case "yogurt":
      return (
        <Frame className={className}>
          <rect x="34" y="38" width="52" height="48" rx="12" fill="#FFFBF4" />
          <ellipse cx="60" cy="42" rx="26" ry="10" fill="#E4D9C8" />
          <circle cx="52" cy="40" r="6" fill="#C2663A" />
          <circle cx="66" cy="38" r="5" fill="#5F6E32" />
        </Frame>
      );
    case "omelette":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="64" rx="38" ry="24" fill="#F6E4D8" />
          <ellipse cx="60" cy="62" rx="28" ry="16" fill="#C2663A" opacity="0.35" />
          <circle cx="50" cy="60" r="5" fill="#5F6E32" />
        </Frame>
      );
    case "rice":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="82" rx="34" ry="12" fill="#5F6E32" />
          <ellipse cx="60" cy="64" rx="30" ry="22" fill="#FFFBF4" />
          <circle cx="60" cy="48" r="14" fill="#C2663A" />
        </Frame>
      );
    case "pasta":
      return (
        <Frame className={className}>
          <rect x="26" y="40" width="68" height="44" rx="16" fill="#FFFBF4" />
          <path
            d="M34 58c8-8 16 8 24 0s16 8 24 0 16 8 24 0"
            fill="none"
            stroke="#C2663A"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <path
            d="M34 70c8-8 16 8 24 0s16 8 24 0 16 8 24 0"
            fill="none"
            stroke="#5F6E32"
            strokeWidth="5"
            strokeLinecap="round"
          />
        </Frame>
      );
    case "stew":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="78" rx="36" ry="16" fill="#4A5726" />
          <ellipse cx="60" cy="62" rx="32" ry="20" fill="#C2663A" />
          <circle cx="50" cy="60" r="6" fill="#5F6E32" />
          <circle cx="70" cy="58" r="5" fill="#F6E4D8" />
        </Frame>
      );
    case "salad":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="78" rx="34" ry="12" fill="#FFFBF4" />
          <circle cx="48" cy="58" r="16" fill="#5F6E32" />
          <circle cx="72" cy="56" r="14" fill="#4A5726" />
          <circle cx="60" cy="50" r="10" fill="#C2663A" />
        </Frame>
      );
    case "chicken":
      return (
        <Frame className={className}>
          <ellipse cx="62" cy="68" rx="28" ry="20" fill="#C2663A" />
          <circle cx="44" cy="52" r="14" fill="#F6E4D8" />
          <rect x="70" y="44" width="10" height="22" rx="5" fill="#5F6E32" />
        </Frame>
      );
    case "soup":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="80" rx="36" ry="12" fill="#5F6E32" />
          <ellipse cx="60" cy="66" rx="30" ry="16" fill="#C2663A" />
          <path d="M48 44c4-10 20-10 24 0" fill="none" stroke="#8A8276" strokeWidth="3" />
        </Frame>
      );
    case "fish":
      return (
        <Frame className={className}>
          <ellipse cx="56" cy="60" rx="28" ry="16" fill="#5F6E32" />
          <polygon points="84,60 104,46 104,74" fill="#4A5726" />
          <circle cx="42" cy="56" r="3" fill="#FFFBF4" />
        </Frame>
      );
    case "mushrooms":
      return (
        <Frame className={className}>
          <rect x="42" y="60" width="12" height="24" rx="6" fill="#F6E4D8" />
          <ellipse cx="48" cy="56" rx="18" ry="12" fill="#C2663A" />
          <rect x="68" y="64" width="10" height="20" rx="5" fill="#F6E4D8" />
          <ellipse cx="73" cy="60" rx="14" ry="10" fill="#5F6E32" />
        </Frame>
      );
    case "smoothie":
      return (
        <Frame className={className}>
          <path d="M42 36h36l-6 52H48z" fill="#C2663A" />
          <rect x="46" y="28" width="28" height="10" rx="5" fill="#5F6E32" />
          <rect x="58" y="18" width="4" height="16" rx="2" fill="#2A261D" />
        </Frame>
      );
    case "fruit":
      return (
        <Frame className={className}>
          <circle cx="52" cy="64" r="20" fill="#C2663A" />
          <circle cx="74" cy="58" r="16" fill="#5F6E32" />
          <rect x="70" y="36" width="6" height="12" rx="3" fill="#4A5726" />
        </Frame>
      );
    case "cookies":
      return (
        <Frame className={className}>
          <circle cx="46" cy="64" r="18" fill="#C2663A" />
          <circle cx="74" cy="56" r="16" fill="#F6E4D8" />
          <circle cx="42" cy="60" r="3" fill="#4A5726" />
          <circle cx="52" cy="70" r="3" fill="#4A5726" />
          <circle cx="70" cy="52" r="2.5" fill="#5F6E32" />
        </Frame>
      );
    case "hummus":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="78" rx="34" ry="12" fill="#E4D9C8" />
          <ellipse cx="60" cy="62" rx="28" ry="18" fill="#F6E4D8" />
          <ellipse cx="60" cy="60" rx="10" ry="6" fill="#C2663A" />
        </Frame>
      );
    case "potato":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="64" rx="32" ry="22" fill="#C2663A" />
          <ellipse cx="60" cy="64" rx="22" ry="14" fill="#F6E4D8" />
        </Frame>
      );
    case "tofu":
      return (
        <Frame className={className}>
          <rect x="32" y="40" width="56" height="44" rx="10" fill="#FFFBF4" />
          <rect x="40" y="48" width="18" height="18" rx="4" fill="#E7EDD4" />
          <rect x="62" y="48" width="18" height="18" rx="4" fill="#E7EDD4" />
        </Frame>
      );
    case "wrap":
      return (
        <Frame className={className}>
          <ellipse cx="60" cy="62" rx="36" ry="22" fill="#F6E4D8" />
          <path d="M30 62c12 16 48 16 60 0" fill="#5F6E32" />
        </Frame>
      );
    default:
      return (
        <Frame className={className}>
          <circle cx="60" cy="60" r="22" fill="#5F6E32" />
        </Frame>
      );
  }
}
