import { useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import { INGREDIENT_GROUPS, INGREDIENTS } from "@/data/ingredients";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function IngredientPicker() {
  const selected = useAppStore((s) => s.ingredientIds);
  const toggle = useAppStore((s) => s.toggleIngredient);
  const clear = useAppStore((s) => s.clearIngredients);
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return INGREDIENTS;
    return INGREDIENTS.filter((item) => item.name.toLowerCase().includes(q));
  }, [query]);

  const selectedSet = new Set(selected);

  return (
    <section>
      <div className="flex items-end justify-between gap-3">
        <h2 className="font-display text-xl text-ink">Qué tienes</h2>
        {selected.length > 0 ? (
          <button
            type="button"
            className="h-11 text-sm font-semibold text-olive"
            onClick={clear}
          >
            Limpiar
          </button>
        ) : null}
      </div>

      {selected.length > 0 ? (
        <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
          {selected.map((id) => {
            const item = INGREDIENTS.find((ing) => ing.id === id);
            if (!item) return null;
            return (
              <button
                key={id}
                type="button"
                onClick={() => toggle(id)}
                className="inline-flex h-10 shrink-0 items-center gap-1 rounded-full bg-olive px-3 text-sm font-semibold text-surface"
              >
                {item.name}
                <X className="size-3.5" />
              </button>
            );
          })}
        </div>
      ) : null}

      <label className="mt-3 flex h-12 items-center gap-2 rounded-[16px] bg-surface px-3 shadow-[var(--shadow-card)]">
        <Search className="size-4 text-muted" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar ingrediente"
          className="h-full w-full bg-transparent text-base text-ink outline-none placeholder:text-muted"
        />
      </label>

      <div className="mt-4 space-y-4">
        {INGREDIENT_GROUPS.map((group) => {
          const items = filtered.filter((item) => item.group === group.id);
          if (items.length === 0) return null;
          return (
            <div key={group.id}>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">
                {group.label}
              </p>
              <div className="flex flex-wrap gap-2">
                {items.map((item) => {
                  const on = selectedSet.has(item.id);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => toggle(item.id)}
                      className={cn(
                        "h-11 rounded-full px-3.5 text-sm font-semibold transition-colors duration-150",
                        on
                          ? "bg-olive text-surface"
                          : "bg-surface text-ink shadow-[var(--shadow-card)]",
                      )}
                    >
                      {item.name}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
