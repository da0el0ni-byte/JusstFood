import { Link } from "@tanstack/react-router";
import { Clock, Heart } from "lucide-react";
import { RecipeIllustration } from "@/components/RecipeIllustration";
import { ingredientName } from "@/data/ingredients";
import type { ScoredRecipe } from "@/data/types";
import { CATEGORY_LABEL, DIFFICULTY_LABEL, formatMinutes } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export function RecipeCard({ scored }: { scored: ScoredRecipe }) {
  const { recipe, matchCount, total, missing } = scored;
  const favorite = useAppStore((s) => s.favorites.includes(recipe.id));
  const toggleFavorite = useAppStore((s) => s.toggleFavorite);

  return (
    <article className="relative rounded-[28px] bg-surface p-3 shadow-[var(--shadow-card)]">
      <Link
        to="/recipe/$id"
        params={{ id: recipe.id }}
        className="flex gap-3"
      >
        <div className="size-[88px] shrink-0 overflow-hidden rounded-[20px]">
          <RecipeIllustration kind={recipe.illustration} />
        </div>
        <div className="min-w-0 flex-1 pr-8">
          <p className="text-xs font-semibold uppercase tracking-wide text-olive">
            {CATEGORY_LABEL[recipe.category]}
          </p>
          <h2 className="font-display text-lg leading-snug text-ink">{recipe.name}</h2>
          <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-ink-soft">
            <span className="inline-flex items-center gap-1">
              <Clock className="size-3.5" />
              {formatMinutes(recipe.timeMinutes)}
            </span>
            <span>{DIFFICULTY_LABEL[recipe.difficulty]}</span>
          </div>
          <p className="mt-2 text-sm font-semibold text-olive-deep">
            Usas {matchCount} de {total} ingredientes
          </p>
          {missing.length > 0 ? (
            <p className="mt-1 line-clamp-2 text-xs text-terra">
              Falta: {missing.map((item) => ingredientName(item.id)).join(", ")}
            </p>
          ) : (
            <p className="mt-1 text-xs font-semibold text-good">La puedes hacer ahora</p>
          )}
        </div>
      </Link>
      <button
        type="button"
        className={cn(
          "absolute top-3 right-3 flex size-11 items-center justify-center rounded-full",
          favorite ? "text-terra" : "text-muted",
        )}
        aria-label={favorite ? "Quitar de favoritos" : "Guardar en favoritos"}
        onClick={(event) => {
          event.preventDefault();
          toggleFavorite(recipe.id);
        }}
      >
        <Heart className="size-5" fill={favorite ? "currentColor" : "none"} />
      </button>
    </article>
  );
}
