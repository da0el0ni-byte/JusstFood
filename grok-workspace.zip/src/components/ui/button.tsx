import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-semibold transition-[transform,background-color,color,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-olive",
  {
    variants: {
      variant: {
        primary: "bg-olive text-surface hover:bg-olive-deep",
        secondary: "bg-olive-soft text-olive-deep hover:bg-olive/20",
        ghost: "bg-transparent text-ink hover:bg-surface-2",
        terra: "bg-terra text-surface hover:bg-terra/90",
        outline: "bg-surface text-ink shadow-[var(--shadow-card)]",
      },
      size: {
        md: "h-12 rounded-[16px] px-5 text-base",
        lg: "h-14 rounded-[20px] px-6 text-lg",
        sm: "h-10 rounded-[12px] px-3.5 text-sm",
        icon: "size-11 rounded-full",
      },
    },
    defaultVariants: {
      variant: "primary",
      size: "md",
    },
  },
);

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>;

export function Button({ className, variant, size, ...props }: ButtonProps) {
  return (
    <button className={cn(buttonVariants({ variant, size }), className)} {...props} />
  );
}
