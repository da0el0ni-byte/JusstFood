import type { ReactNode } from "react";
import { useEffect } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Heart, House, SlidersHorizontal } from "lucide-react";
import { cn } from "@/lib/utils";
import { AdInterstitial } from "@/components/ads/AdInterstitial";
import { AdRewarded } from "@/components/ads/AdRewarded";
import { TimerTicker } from "@/components/Timer";
import { useAppStore } from "@/lib/store";

const TABS = [
  { to: "/", label: "Inicio", icon: House },
  { to: "/favorites", label: "Favoritos", icon: Heart },
  { to: "/settings", label: "Ajustes", icon: SlidersHorizontal },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hideNav = pathname.startsWith("/recipe/");

  useEffect(() => {
    void Promise.resolve(useAppStore.persist.rehydrate()).finally(() => {
      useAppStore.getState().setHydrated(true);
    });
  }, []);

  return (
    <div className="min-h-dvh bg-bg-deep">
      <TimerTicker />
      <AdInterstitial />
      <AdRewarded />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col bg-bg shadow-[0_0_0_1px_rgb(42_38_29_/_0.06),0_24px_60px_-24px_rgb(42_38_29_/_0.35)]">
        <div className="flex min-h-dvh flex-col">{children}</div>
        {!hideNav ? (
          <nav
            className="sticky bottom-0 z-30 border-t border-line bg-surface/95 px-3 pt-2 backdrop-blur-sm"
            style={{ paddingBottom: "max(10px, env(safe-area-inset-bottom))" }}
          >
            <ul className="grid grid-cols-3 gap-1">
              {TABS.map((tab) => {
                const active =
                  tab.to === "/"
                    ? pathname === "/" || pathname.startsWith("/results")
                    : pathname === tab.to;
                const Icon = tab.icon;
                return (
                  <li key={tab.to}>
                    <Link
                      to={tab.to}
                      className={cn(
                        "flex h-14 flex-col items-center justify-center gap-1 rounded-[16px] text-xs font-semibold transition-colors duration-150",
                        active ? "bg-olive-soft text-olive-deep" : "text-muted",
                      )}
                    >
                      <Icon className="size-5" strokeWidth={active ? 2.4 : 2} />
                      {tab.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        ) : null}
      </div>
    </div>
  );
}
