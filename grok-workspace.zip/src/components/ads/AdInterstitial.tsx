import { useEffect } from "react";
import { ADMOB, isTestAdId } from "@/lib/ads";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";

export function AdInterstitial() {
  const visible = useAppStore((s) => s.interstitialVisible);
  const hide = useAppStore((s) => s.hideInterstitial);
  const timerRunning = useAppStore((s) => s.timer.running);

  useEffect(() => {
    if (!visible) return;
    if (timerRunning) {
      hide();
      return;
    }
    const id = window.setTimeout(hide, 4000);
    return () => window.clearTimeout(id);
  }, [visible, timerRunning, hide]);

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Anuncio intersticial de prueba"
    >
      <div className="w-full max-w-sm rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]">
        <p className="text-xs font-bold uppercase tracking-wide text-muted">Anuncio de prueba</p>
        <p className="mt-3 font-display text-2xl text-ink">Google AdMob</p>
        <p className="mt-2 text-sm text-ink-soft">
          Intersticial de desarrollo. No se muestra al abrir la app ni durante una receta o el temporizador.
        </p>
        <p className="mt-3 font-mono text-[10px] text-muted">{ADMOB.interstitialId}</p>
        {isTestAdId(ADMOB.interstitialId) ? (
          <p className="mt-1 text-xs font-semibold text-terra">ID de prueba</p>
        ) : null}
        <Button className="mt-5 w-full" variant="secondary" onClick={hide}>
          Cerrar
        </Button>
      </div>
    </div>
  );
}
