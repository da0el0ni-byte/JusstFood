import { ADS_DISABLED_BY_DEFAULT, ADMOB, BANNER_RESERVED_PX, isTestAdId } from "@/lib/ads";
import { useAppStore } from "@/lib/store";

export function AdBanner() {
  const adsDisabled = useAppStore((s) => s.adsDisabled);
  if (ADS_DISABLED_BY_DEFAULT || adsDisabled) return null;

  return (
    <aside
      className="border-t border-line bg-surface-2"
      style={{ minHeight: BANNER_RESERVED_PX }}
      aria-label="Espacio de anuncio"
    >
      <div className="flex h-16 items-center justify-center gap-3 px-4">
        <span className="rounded-sm bg-ink px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-surface">
          Anuncio
        </span>
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold text-ink-soft">Anuncio de prueba AdMob</p>
          <p className="truncate font-mono text-[10px] text-muted">{ADMOB.bannerId}</p>
        </div>
        {isTestAdId(ADMOB.bannerId) ? (
          <span className="shrink-0 text-[10px] font-semibold uppercase text-terra">Test</span>
        ) : null}
      </div>
    </aside>
  );
}
