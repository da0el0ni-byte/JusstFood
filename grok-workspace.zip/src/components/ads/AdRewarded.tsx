import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { ADMOB, isTestAdId } from "@/lib/ads";
import { pickSurpriseRecipe } from "@/lib/search";
import { useAppStore } from "@/lib/store";
import { Button } from "@/components/ui/button";

export function AdRewarded() {
  const visible = useAppStore((s) => s.rewardedVisible);
  const hide = useAppStore((s) => s.hideRewarded);
  const opened = useAppStore((s) => s.openedRecipeIds);
  const navigate = useNavigate();
  const [seconds, setSeconds] = useState(5);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!visible) {
      setSeconds(5);
      setDone(false);
      return;
    }
    setSeconds(5);
    setDone(false);
    const id = window.setInterval(() => {
      setSeconds((n) => {
        if (n <= 1) {
          window.clearInterval(id);
          setDone(true);
          return 0;
        }
        return n - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [visible]);

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-6"
      role="dialog"
      aria-modal="true"
      aria-label="Anuncio recompensado opcional"
    >
      <div className="w-full max-w-sm rounded-[28px] bg-surface p-6 text-center shadow-[var(--shadow-card)]">
        <p className="text-xs font-bold uppercase tracking-wide text-muted">Anuncio opcional</p>
        <p className="mt-3 font-display text-2xl text-ink">Receta sorpresa</p>
        <p className="mt-2 text-sm text-ink-soft">
          Mira este anuncio de prueba y te mostramos una receta al azar de la colección.
        </p>
        <p className="mt-3 font-mono text-[10px] text-muted">{ADMOB.rewardedId}</p>
        {isTestAdId(ADMOB.rewardedId) ? (
          <p className="mt-1 text-xs font-semibold text-terra">ID de prueba</p>
        ) : null}
        {!done ? (
          <p className="mt-5 font-display text-4xl tabular-nums text-olive">{seconds}</p>
        ) : (
          <Button
            className="mt-5 w-full"
            onClick={() => {
              const recipe = pickSurpriseRecipe(opened);
              hide();
              if (recipe) void navigate({ to: "/recipe/$id", params: { id: recipe.id } });
            }}
          >
            Ver receta sorpresa
          </Button>
        )}
        <Button className="mt-3 w-full" variant="ghost" onClick={hide}>
          Cancelar
        </Button>
      </div>
    </div>
  );
}
